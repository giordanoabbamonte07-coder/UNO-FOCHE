var graphics_8h =
[
    [ "Grafica", "struct_grafica.html", "struct_grafica" ],
    [ "CARTA_ALTEZZA", "graphics_8h.html#a4cbcfaf3f2acf5c85d0d91eb928bf0cf", null ],
    [ "CARTA_LARGHEZZA", "graphics_8h.html#a5f25862f5aaf31948e307f08d7fc9376", null ],
    [ "CaricaSicuro", "graphics_8h.html#aafdc5beb9128c3f400b3592a23adb3fb", null ],
    [ "DisegnaPartita", "graphics_8h.html#af80ef27d7924e3e196fb780c38d31af1", null ],
    [ "DisegnaTestoPixelGrassetto", "graphics_8h.html#a7b41d6447819a799f28ec26a8ee65d9b", null ],
    [ "InizializzaGrafica", "graphics_8h.html#a1a1f999ac837e2860330667c594bfc48", null ],
    [ "ScaricaGrafica", "graphics_8h.html#acf092cde69a7326412b8967851c26b8e", null ]
];