var archivio_8h =
[
    [ "MAX_SALVATAGGI_PER_UTENTE", "archivio_8h.html#a7076962fd648c56cc26a4c638f8c93c3", null ],
    [ "CaricaPartiteSospeseUtente", "archivio_8h.html#a58e05485dbee98bd3004e25e3135335e", null ],
    [ "DisegnaArchivioStorico", "archivio_8h.html#a0a97c89f0e9c7d9e2bab78f222950aca", null ],
    [ "EliminaPartitaDaArchivio", "archivio_8h.html#a4bcf966145e0aee2e1064a7768b3d350", null ],
    [ "InizializzaRisorseArchivio", "archivio_8h.html#a55712d53701eaf266a8c7cd6dbc59cdd", null ],
    [ "OttieniStatisticheUtente", "archivio_8h.html#a5c1889226e8e84b71513037a0e889dab", null ],
    [ "PreparaArchivioStorico", "archivio_8h.html#aac875619d353e8f9f4c6087c7efa283d", null ],
    [ "SalvaPartitaSospesa", "archivio_8h.html#af8d26044be1ee4d4819311d8ea786576", null ],
    [ "SalvaRisultatoPartita", "archivio_8h.html#a25074f360d01d5d6451ed7206b9f282e", null ],
    [ "ScaricaRisorseArchivio", "archivio_8h.html#a1e0acc9358a505da02f123c0d12eb562", null ],
    [ "btnAvanti", "archivio_8h.html#ae16ceed85cbf05cc67bca1125b253d3a", null ],
    [ "btnIndietro", "archivio_8h.html#a4c42545da65859b4ed64c59a50e54317", null ],
    [ "rectAvanti", "archivio_8h.html#ae365c6067c2f5a54d0d1595f8fa1c6ec", null ],
    [ "rectIndietro", "archivio_8h.html#ad887d409244d4a4d47f14a4d90d263cd", null ],
    [ "sfondoStatistiche", "archivio_8h.html#ac9da2322d5949840a7837a36348757e6", null ]
];