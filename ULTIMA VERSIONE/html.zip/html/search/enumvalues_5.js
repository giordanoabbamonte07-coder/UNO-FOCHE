var searchData=
[
  ['piu_5fdue_0',['PIU_DUE',['../game_8h.html#adbc6fd1c40bcc87f0ffb9a41a4a4155aa581bd7682ee49c6ef2aed15703e34491',1,'game.h']]],
  ['piu_5fquattro_1',['PIU_QUATTRO',['../game_8h.html#adbc6fd1c40bcc87f0ffb9a41a4a4155aafca5f3472b00061a1859b891565b1bc4',1,'game.h']]]
];
