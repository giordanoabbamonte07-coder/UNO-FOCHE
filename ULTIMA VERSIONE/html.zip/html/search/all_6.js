var searchData=
[
  ['game_0',['Modulo &lt;span class=&quot;tt&quot;&gt;game&lt;/span&gt;',['../md__r_e_a_d_m_e.html#autotoc_md6',1,'']]],
  ['game_2ec_1',['game.c',['../game_8c.html',1,'']]],
  ['game_2eh_2',['game.h',['../game_8h.html',1,'']]],
  ['generale_20dell_20applicazione_3',['Flusso generale dell&apos;applicazione',['../md__r_e_a_d_m_e.html#autotoc_md5',1,'']]],
  ['generati_20o_20usati_4',['File dati generati o usati',['../md__r_e_a_d_m_e.html#autotoc_md19',1,'']]],
  ['gestione_20degli_20asset_5',['Gestione degli asset',['../md__r_e_a_d_m_e.html#autotoc_md20',1,'']]],
  ['gestisceinput_6',['GestisceInput',['../game_8c.html#a425a6a4553385e952485f24b57faeff5',1,'GestisceInput(Partita *p):&#160;game.c'],['../game_8h.html#a425a6a4553385e952485f24b57faeff5',1,'GestisceInput(Partita *p):&#160;game.c']]],
  ['gestiscischermataauth_7',['GestisciSchermataAuth',['../menu_8c.html#aedaf59d96aedebada1c5aeed178097d9',1,'GestisciSchermataAuth(MenuGrafica *mg, StatoGioco stato):&#160;menu.c'],['../menu_8h.html#aedaf59d96aedebada1c5aeed178097d9',1,'GestisciSchermataAuth(MenuGrafica *mg, StatoGioco stato):&#160;menu.c']]],
  ['giallo_8',['GIALLO',['../game_8h.html#a030035d63f7ea5baefdfe9a53844d27cab43fc5129914206a77c76e0cffd20df2',1,'game.h']]],
  ['giocatore_9',['Giocatore',['../struct_giocatore.html',1,'']]],
  ['giocatorehamosse_10',['GiocatoreHaMosse',['../game_8c.html#a9b7733214ce574619e98b158c49e005e',1,'GiocatoreHaMosse(Partita *p, int id_giocatore):&#160;game.c'],['../game_8h.html#a9b7733214ce574619e98b158c49e005e',1,'GiocatoreHaMosse(Partita *p, int id_giocatore):&#160;game.c']]],
  ['giocatori_11',['giocatori',['../struct_partita.html#a87b92ab4bf8a1caf7da7bdde4818e48b',1,'Partita']]],
  ['gioco_12',['Flusso tipico di gioco',['../md__r_e_a_d_m_e.html#autotoc_md22',1,'']]],
  ['grafica_13',['Grafica',['../struct_grafica.html',1,'']]],
  ['graphics_14',['Modulo &lt;span class=&quot;tt&quot;&gt;graphics&lt;/span&gt;',['../md__r_e_a_d_m_e.html#autotoc_md10',1,'']]],
  ['graphics_2ec_15',['graphics.c',['../graphics_8c.html',1,'']]],
  ['graphics_2eh_16',['graphics.h',['../graphics_8h.html',1,'']]]
];
