var searchData=
[
  ['partita_5ffinita_0',['partita_finita',['../struct_partita.html#add026eaab4c5437233432e20ac2764ec',1,'Partita']]],
  ['pass_1',['pass',['../struct_record_accesso.html#ade137af880b61e4c68fb2dcc274dd1c0',1,'RecordAccesso']]],
  ['password_2',['password',['../struct_log_accesso.html#a31e8e8d75a558616beda2db0705befb4',1,'LogAccesso::password'],['../struct_menu_grafica.html#a9ff5f387df67f4aa7fed563cd905bce8',1,'MenuGrafica::password'],['../struct_utente_registrato.html#a31e8e8d75a558616beda2db0705befb4',1,'UtenteRegistrato::password']]],
  ['pos_5fx_5fdeltaplano_3',['pos_x_deltaplano',['../struct_partita.html#a14ff56c7e9bbd7a50dab3f392646b01e',1,'Partita']]],
  ['posizione_5fanimazione_4',['posizione_animazione',['../struct_partita.html#a6d9cea2ee169eeeb3b6d25a5d6e05835',1,'Partita']]],
  ['prossimo_5fturno_5',['prossimo_turno',['../struct_partita.html#a0eed4afe8bd32bfebf539585bbb70b1a',1,'Partita']]],
  ['puo_5fpassare_6',['puo_passare',['../struct_partita.html#a1857acff64dd9b26571d17c66bba5add',1,'Partita']]]
];
