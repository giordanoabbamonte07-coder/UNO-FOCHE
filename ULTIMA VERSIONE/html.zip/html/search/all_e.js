var searchData=
[
  ['readme_2emd_0',['README.md',['../_r_e_a_d_m_e_8md.html',1,'']]],
  ['recordaccesso_1',['RecordAccesso',['../struct_record_accesso.html',1,'']]],
  ['recordsalvataggio_2',['RecordSalvataggio',['../struct_record_salvataggio.html',1,'']]],
  ['rect1vs1_3',['rect1vs1',['../struct_menu_scelta.html#ab916f81ef206d996f5cc47719e0e2961',1,'MenuScelta']]],
  ['rectarchivio_4',['rectArchivio',['../struct_menu_scelta.html#add6af26ec9bdef9d00adbeb0f3f355cd',1,'MenuScelta']]],
  ['rectavanti_5',['rectAvanti',['../archivio_8h.html#ae365c6067c2f5a54d0d1595f8fa1c6ec',1,'rectAvanti:&#160;main.c'],['../main_8c.html#ae365c6067c2f5a54d0d1595f8fa1c6ec',1,'rectAvanti:&#160;main.c']]],
  ['rectimpostazioni_6',['rectImpostazioni',['../struct_menu_scelta.html#ac802f5459077e865a141044962453704',1,'MenuScelta']]],
  ['rectindietro_7',['rectIndietro',['../struct_menu_scelta.html#ad887d409244d4a4d47f14a4d90d263cd',1,'MenuScelta::rectIndietro'],['../archivio_8h.html#ad887d409244d4a4d47f14a4d90d263cd',1,'rectIndietro:&#160;main.c'],['../main_8c.html#ad887d409244d4a4d47f14a4d90d263cd',1,'rectIndietro:&#160;main.c']]],
  ['rectmulti_8',['rectMulti',['../struct_menu_scelta.html#a57bae0b9f98ddbe049673942c5ad5721',1,'MenuScelta']]],
  ['rectonaudio_9',['rectOnAudio',['../struct_menu_scelta.html#a5de254809e9c500d2854cc7cff605671',1,'MenuScelta']]],
  ['rectonmusica_10',['rectOnMusica',['../struct_menu_scelta.html#ad6cbcae77e97b5dd2997b8b3ebaf3cfc',1,'MenuScelta']]],
  ['rectregole_11',['rectRegole',['../struct_menu_scelta.html#af1e6e5e0ffefa9e2d6fc7ef8f06b2034',1,'MenuScelta']]],
  ['regole_20implementate_12',['Regole implementate',['../md__r_e_a_d_m_e.html#autotoc_md9',1,'']]],
  ['retro_13',['retro',['../struct_grafica.html#ab894ac900979555aff76b2a677791fe7',1,'Grafica']]],
  ['richiedi_5fuscita_14',['richiedi_uscita',['../struct_partita.html#a847671f67b8c18ba296bfe0bfd4dfde7',1,'Partita']]],
  ['rosso_15',['ROSSO',['../game_8h.html#a030035d63f7ea5baefdfe9a53844d27caf31d451540fbe9019951dc44d57cada9',1,'game.h']]]
];
