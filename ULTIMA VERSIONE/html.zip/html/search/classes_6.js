var searchData=
[
  ['utenteregistrato_0',['UtenteRegistrato',['../struct_utente_registrato.html',1,'']]]
];
