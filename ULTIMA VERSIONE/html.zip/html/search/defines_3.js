var searchData=
[
  ['vai_5f1vs1_0',['VAI_1VS1',['../menu__scelta_8h.html#a496810aba8c641824ff194cc1a8d0019',1,'menu_scelta.h']]],
  ['vai_5farchivio_1',['VAI_ARCHIVIO',['../menu__scelta_8h.html#a98cff792e2069ed18baa47f4c1fe595d',1,'menu_scelta.h']]],
  ['vai_5fimpostazioni_2',['VAI_IMPOSTAZIONI',['../menu__scelta_8h.html#a91b43b6674fca50a5664b29fcba5b05e',1,'menu_scelta.h']]],
  ['vai_5findietro_3',['VAI_INDIETRO',['../menu__scelta_8h.html#a570b56abe9045f6ef57a9bc3705caa84',1,'menu_scelta.h']]],
  ['vai_5fmultigiocatore_4',['VAI_MULTIGIOCATORE',['../menu__scelta_8h.html#ab8c21e22ebac4b86a10a70f27139d1fa',1,'menu_scelta.h']]],
  ['vai_5fregole_5',['VAI_REGOLE',['../menu__scelta_8h.html#acdc7329b766c4a8af8cdff608bdf2dce',1,'menu_scelta.h']]]
];
