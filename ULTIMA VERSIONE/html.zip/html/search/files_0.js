var searchData=
[
  ['archivio_2ec_0',['archivio.c',['../archivio_8c.html',1,'']]],
  ['archivio_2eh_1',['archivio.h',['../archivio_8h.html',1,'']]],
  ['audio_2ec_2',['audio.c',['../audio_8c.html',1,'']]],
  ['audio_2eh_3',['audio.h',['../audio_8h.html',1,'']]]
];
