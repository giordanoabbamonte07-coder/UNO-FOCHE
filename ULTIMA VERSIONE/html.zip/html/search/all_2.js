var searchData=
[
  ['cambia_5fcolore_0',['CAMBIA_COLORE',['../game_8h.html#adbc6fd1c40bcc87f0ffb9a41a4a4155aa093e6adbf5e8b70aafcc3b56c641f31c',1,'game.h']]],
  ['campo_5fattivo_1',['campo_attivo',['../struct_menu_grafica.html#a7b271356cc5af1fadbde0ce4847077f2',1,'MenuGrafica']]],
  ['caricapartitesospeseutente_2',['CaricaPartiteSospeseUtente',['../archivio_8c.html#a58e05485dbee98bd3004e25e3135335e',1,'CaricaPartiteSospeseUtente(const char *username, Partita elencoPartite[]):&#160;archivio.c'],['../archivio_8h.html#a58e05485dbee98bd3004e25e3135335e',1,'CaricaPartiteSospeseUtente(const char *username, Partita elencoPartite[]):&#160;archivio.c']]],
  ['caricasicuro_3',['CaricaSicuro',['../graphics_8c.html#aafdc5beb9128c3f400b3592a23adb3fb',1,'CaricaSicuro(const char *path):&#160;graphics.c'],['../graphics_8h.html#aafdc5beb9128c3f400b3592a23adb3fb',1,'CaricaSicuro(const char *path):&#160;graphics.c']]],
  ['carta_4',['Carta',['../struct_carta.html',1,'']]],
  ['carta_5faltezza_5',['CARTA_ALTEZZA',['../game_8h.html#a4cbcfaf3f2acf5c85d0d91eb928bf0cf',1,'CARTA_ALTEZZA:&#160;game.h'],['../graphics_8h.html#a4cbcfaf3f2acf5c85d0d91eb928bf0cf',1,'CARTA_ALTEZZA:&#160;graphics.h']]],
  ['carta_5fanimata_6',['carta_animata',['../struct_partita.html#a28c4e281c43e465398d2ffa86c34c631',1,'Partita']]],
  ['carta_5flarghezza_7',['CARTA_LARGHEZZA',['../game_8h.html#a5f25862f5aaf31948e307f08d7fc9376',1,'CARTA_LARGHEZZA:&#160;game.h'],['../graphics_8h.html#a5f25862f5aaf31948e307f08d7fc9376',1,'CARTA_LARGHEZZA:&#160;graphics.h']]],
  ['carte_8',['carte',['../struct_grafica.html#a7c627bd1fe9469884fad0c4869256288',1,'Grafica']]],
  ['carte_5fmazzo_9',['carte_mazzo',['../struct_partita.html#a8ea544ae6f684427e48fd6a141285c23',1,'Partita']]],
  ['cima_10',['cima',['../struct_partita.html#a849deaf3d237be3cae4eaa02a273283c',1,'Partita']]],
  ['closeaudio_11',['CloseAudio',['../audio_8c.html#abc629cd09bb702266545d28b5a436814',1,'CloseAudio(void):&#160;audio.c'],['../audio_8h.html#abc629cd09bb702266545d28b5a436814',1,'CloseAudio(void):&#160;audio.c']]],
  ['codice_12',['UNO Foca - Documentazione del codice',['../md__r_e_a_d_m_e.html',1,'']]],
  ['colore_13',['Colore',['../game_8h.html#a030035d63f7ea5baefdfe9a53844d27c',1,'game.h']]],
  ['colore_14',['colore',['../struct_carta.html#a489426ff15ee3d43b4fa14d4760cb232',1,'Carta']]],
  ['colore_5fattuale_15',['colore_attuale',['../struct_partita.html#afe86c59bf78fa43d5d9fd2cb509adda7',1,'Partita']]],
  ['colore_5ftesto_5fdata_16',['COLORE_TESTO_DATA',['../game_8h.html#aa54e9dcd9721049babd2c1cd469363de',1,'game.h']]],
  ['colore_5ftesto_5fevento_17',['COLORE_TESTO_EVENTO',['../game_8h.html#ab9297a173856fc545a0657edb2aaa680',1,'game.h']]],
  ['compilazione_20ed_20esecuzione_18',['Compilazione ed esecuzione',['../md__r_e_a_d_m_e.html#autotoc_md3',1,'']]],
  ['consultare_19',['File principali da consultare',['../md__r_e_a_d_m_e.html#autotoc_md23',1,'']]],
  ['creafallback_20',['CreaFallback',['../graphics_8c.html#aab5f6f3bf7cacfe7aee1d9245df34127',1,'graphics.c']]]
];
