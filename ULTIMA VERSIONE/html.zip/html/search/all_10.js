var searchData=
[
  ['tecnologie_20e_20dipendenze_0',['Tecnologie e dipendenze',['../md__r_e_a_d_m_e.html#autotoc_md2',1,'']]],
  ['tex_5fpassword_1',['tex_password',['../struct_menu_grafica.html#a28b65360e2d43d19ad8240ef85e007bd',1,'MenuGrafica']]],
  ['tex_5futente_2',['tex_utente',['../struct_menu_grafica.html#a6703520234c955336a846ca639e980e4',1,'MenuGrafica']]],
  ['timer_5fanim_3',['timer_anim',['../struct_partita.html#a988243aaf356595c1251bb67e7c28484',1,'Partita']]],
  ['timer_5fattesa_4',['timer_attesa',['../struct_partita.html#aa81ef78cee5e05e5ab24ede10a941532',1,'Partita']]],
  ['timer_5fmessaggio_5',['timer_messaggio',['../struct_partita.html#a192a1a5c9b51451e8d0ca305a9ab6af0',1,'Partita']]],
  ['tipico_20di_20gioco_6',['Flusso tipico di gioco',['../md__r_e_a_d_m_e.html#autotoc_md22',1,'']]],
  ['tipo_7',['Tipo',['../game_8h.html#adbc6fd1c40bcc87f0ffb9a41a4a4155a',1,'game.h']]],
  ['tipo_8',['tipo',['../struct_carta.html#a2c78f147398843ba78ded425dbb948c4',1,'Carta']]],
  ['tipo_5fazione_9',['tipo_azione',['../struct_log_accesso.html#a2a329361c52810645698d6ec765fa999',1,'LogAccesso']]],
  ['turno_10',['turno',['../struct_partita.html#a958cba121a4e123c9b388d2c1521be4d',1,'Partita']]]
];
