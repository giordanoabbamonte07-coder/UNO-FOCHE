var searchData=
[
  ['eliminapartitadaarchivio_0',['EliminaPartitaDaArchivio',['../archivio_8c.html#a4bcf966145e0aee2e1064a7768b3d350',1,'EliminaPartitaDaArchivio(const char *username, int indiceDaRimuovere):&#160;archivio.c'],['../archivio_8h.html#a4bcf966145e0aee2e1064a7768b3d350',1,'EliminaPartitaDaArchivio(const char *username, int indiceDaRimuovere):&#160;archivio.c']]],
  ['evidenziacarta_1',['EvidenziaCarta',['../graphics_8c.html#a8e5d8ee21a78ad39eadc32b7500effbf',1,'graphics.c']]]
];
