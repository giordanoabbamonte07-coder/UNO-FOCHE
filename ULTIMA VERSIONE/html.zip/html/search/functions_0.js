var searchData=
[
  ['aggiornadisegnamenu_0',['AggiornaDisegnaMenu',['../menu_8c.html#ac22263d5b85dfe545d8289b50f82cf3b',1,'AggiornaDisegnaMenu(MenuGrafica *mg):&#160;menu.c'],['../menu_8h.html#ac22263d5b85dfe545d8289b50f82cf3b',1,'AggiornaDisegnaMenu(MenuGrafica *mg):&#160;menu.c']]],
  ['aggiornadisegnamenuscelta_1',['AggiornaDisegnaMenuScelta',['../menu__scelta_8c.html#ad06c7e7d5f32ae699ac9ec5356124236',1,'AggiornaDisegnaMenuScelta(MenuScelta *menu):&#160;menu_scelta.c'],['../menu__scelta_8h.html#ad06c7e7d5f32ae699ac9ec5356124236',1,'AggiornaDisegnaMenuScelta(MenuScelta *menu):&#160;menu_scelta.c']]],
  ['aggiornapartita_2',['AggiornaPartita',['../game_8c.html#a265ba2456deefe1c0c901dff0ae92a09',1,'AggiornaPartita(Partita *p):&#160;game.c'],['../game_8h.html#a265ba2456deefe1c0c901dff0ae92a09',1,'AggiornaPartita(Partita *p):&#160;game.c']]]
];
