var searchData=
[
  ['caricapartitesospeseutente_0',['CaricaPartiteSospeseUtente',['../archivio_8c.html#a58e05485dbee98bd3004e25e3135335e',1,'CaricaPartiteSospeseUtente(const char *username, Partita elencoPartite[]):&#160;archivio.c'],['../archivio_8h.html#a58e05485dbee98bd3004e25e3135335e',1,'CaricaPartiteSospeseUtente(const char *username, Partita elencoPartite[]):&#160;archivio.c']]],
  ['caricasicuro_1',['CaricaSicuro',['../graphics_8c.html#aafdc5beb9128c3f400b3592a23adb3fb',1,'CaricaSicuro(const char *path):&#160;graphics.c'],['../graphics_8h.html#aafdc5beb9128c3f400b3592a23adb3fb',1,'CaricaSicuro(const char *path):&#160;graphics.c']]],
  ['closeaudio_2',['CloseAudio',['../audio_8c.html#abc629cd09bb702266545d28b5a436814',1,'CloseAudio(void):&#160;audio.c'],['../audio_8h.html#abc629cd09bb702266545d28b5a436814',1,'CloseAudio(void):&#160;audio.c']]],
  ['creafallback_3',['CreaFallback',['../graphics_8c.html#aab5f6f3bf7cacfe7aee1d9245df34127',1,'graphics.c']]]
];
