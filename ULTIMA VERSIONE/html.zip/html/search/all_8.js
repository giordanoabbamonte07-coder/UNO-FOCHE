var searchData=
[
  ['implementate_0',['Regole implementate',['../md__r_e_a_d_m_e.html#autotoc_md9',1,'']]],
  ['impostastatoeffetti_1',['ImpostaStatoEffetti',['../audio_8c.html#abfd4b86126de797ff51b88f8dcf87f87',1,'ImpostaStatoEffetti(bool attiva):&#160;audio.c'],['../audio_8h.html#abfd4b86126de797ff51b88f8dcf87f87',1,'ImpostaStatoEffetti(bool attiva):&#160;audio.c']]],
  ['impostastatomusica_2',['ImpostaStatoMusica',['../audio_8c.html#a34f61171aedc721009397790e6dbb0df',1,'ImpostaStatoMusica(bool attiva):&#160;audio.c'],['../audio_8h.html#a34f61171aedc721009397790e6dbb0df',1,'ImpostaStatoMusica(bool attiva):&#160;audio.c']]],
  ['indice_5fmazzo_3',['indice_mazzo',['../struct_partita.html#abee02839bb454f464877dee4e1fc8462',1,'Partita']]],
  ['initaudio_4',['InitAudio',['../audio_8c.html#a54d939106d7dd8bd3c4d00ca817e4d25',1,'InitAudio(void):&#160;audio.c'],['../audio_8h.html#a54d939106d7dd8bd3c4d00ca817e4d25',1,'InitAudio(void):&#160;audio.c']]],
  ['inizializzagrafica_5',['InizializzaGrafica',['../graphics_8c.html#a1a1f999ac837e2860330667c594bfc48',1,'InizializzaGrafica(Grafica *gfx):&#160;graphics.c'],['../graphics_8h.html#a1a1f999ac837e2860330667c594bfc48',1,'InizializzaGrafica(Grafica *gfx):&#160;graphics.c']]],
  ['inizializzamenu_6',['InizializzaMenu',['../menu_8c.html#a784d0026d039ae89a37b76bb9cb93c65',1,'InizializzaMenu(MenuGrafica *mg):&#160;menu.c'],['../menu_8h.html#a784d0026d039ae89a37b76bb9cb93c65',1,'InizializzaMenu(MenuGrafica *mg):&#160;menu.c']]],
  ['inizializzamenuscelta_7',['InizializzaMenuScelta',['../menu__scelta_8c.html#ab3588acfa6e1da1846ff4dd90a605003',1,'InizializzaMenuScelta(MenuScelta *menu):&#160;menu_scelta.c'],['../menu__scelta_8h.html#ab3588acfa6e1da1846ff4dd90a605003',1,'InizializzaMenuScelta(MenuScelta *menu):&#160;menu_scelta.c']]],
  ['inizializzapartita_8',['InizializzaPartita',['../game_8c.html#a21fda4568f808bf067671e3b008bfd3d',1,'InizializzaPartita(Partita *p, int num_giocatori):&#160;game.c'],['../game_8h.html#a21fda4568f808bf067671e3b008bfd3d',1,'InizializzaPartita(Partita *p, int num_giocatori):&#160;game.c']]],
  ['inizializzarisorsearchivio_9',['InizializzaRisorseArchivio',['../archivio_8c.html#a55712d53701eaf266a8c7cd6dbc59cdd',1,'InizializzaRisorseArchivio(void):&#160;archivio.c'],['../archivio_8h.html#a55712d53701eaf266a8c7cd6dbc59cdd',1,'InizializzaRisorseArchivio(void):&#160;archivio.c']]],
  ['inizio_5fanimazione_10',['inizio_animazione',['../struct_partita.html#a810690171fc829db75154a6402a36528',1,'Partita']]],
  ['inverti_11',['INVERTI',['../game_8h.html#adbc6fd1c40bcc87f0ffb9a41a4a4155aabe537a246f0ae2786411ed65f0060fc5',1,'game.h']]],
  ['is_5fguest_12',['is_guest',['../struct_partita.html#a11c3978f3a78b86b5a8ecf77ee15a189',1,'Partita']]]
];
