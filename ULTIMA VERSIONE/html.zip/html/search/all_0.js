var searchData=
[
  ['aggiornadisegnamenu_0',['AggiornaDisegnaMenu',['../menu_8c.html#ac22263d5b85dfe545d8289b50f82cf3b',1,'AggiornaDisegnaMenu(MenuGrafica *mg):&#160;menu.c'],['../menu_8h.html#ac22263d5b85dfe545d8289b50f82cf3b',1,'AggiornaDisegnaMenu(MenuGrafica *mg):&#160;menu.c']]],
  ['aggiornadisegnamenuscelta_1',['AggiornaDisegnaMenuScelta',['../menu__scelta_8c.html#ad06c7e7d5f32ae699ac9ec5356124236',1,'AggiornaDisegnaMenuScelta(MenuScelta *menu):&#160;menu_scelta.c'],['../menu__scelta_8h.html#ad06c7e7d5f32ae699ac9ec5356124236',1,'AggiornaDisegnaMenuScelta(MenuScelta *menu):&#160;menu_scelta.c']]],
  ['aggiornapartita_2',['AggiornaPartita',['../game_8c.html#a265ba2456deefe1c0c901dff0ae92a09',1,'AggiornaPartita(Partita *p):&#160;game.c'],['../game_8h.html#a265ba2456deefe1c0c901dff0ae92a09',1,'AggiornaPartita(Partita *p):&#160;game.c']]],
  ['anima_5fdeltaplano_3',['anima_deltaplano',['../struct_partita.html#a1c8606f3e39535406ab2dd5808cf794d',1,'Partita']]],
  ['anima_5ffoca_4',['anima_foca',['../struct_partita.html#a7de6722b52cec12463ce1d3f43591793',1,'Partita']]],
  ['animando_5',['animando',['../struct_partita.html#ab002f83d9640e8dc3386e97748cda3fc',1,'Partita']]],
  ['applicazione_6',['Flusso generale dell&apos;applicazione',['../md__r_e_a_d_m_e.html#autotoc_md5',1,'']]],
  ['archivio_7',['Modulo &lt;span class=&quot;tt&quot;&gt;archivio&lt;/span&gt;',['../md__r_e_a_d_m_e.html#autotoc_md16',1,'']]],
  ['archivio_2ec_8',['archivio.c',['../archivio_8c.html',1,'']]],
  ['archivio_2eh_9',['archivio.h',['../archivio_8h.html',1,'']]],
  ['asset_10',['Gestione degli asset',['../md__r_e_a_d_m_e.html#autotoc_md20',1,'']]],
  ['audio_11',['Modulo &lt;span class=&quot;tt&quot;&gt;audio&lt;/span&gt;',['../md__r_e_a_d_m_e.html#autotoc_md11',1,'']]],
  ['audio_2ec_12',['audio.c',['../audio_8c.html',1,'']]],
  ['audio_2eh_13',['audio.h',['../audio_8h.html',1,'']]],
  ['audioattivo_14',['audioAttivo',['../struct_menu_scelta.html#a85d889be71e939ea2d0582d8e112073e',1,'MenuScelta']]],
  ['autenticazione_15',['Autenticazione',['../md__r_e_a_d_m_e.html#autotoc_md14',1,'']]],
  ['azione_16',['azione',['../struct_record_accesso.html#a1a51a5d930bd53beae10cfe8bd0baf58',1,'RecordAccesso']]]
];
