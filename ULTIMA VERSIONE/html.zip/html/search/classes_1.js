var searchData=
[
  ['giocatore_0',['Giocatore',['../struct_giocatore.html',1,'']]],
  ['grafica_1',['Grafica',['../struct_grafica.html',1,'']]]
];
