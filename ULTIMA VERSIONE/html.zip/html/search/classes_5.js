var searchData=
[
  ['recordaccesso_0',['RecordAccesso',['../struct_record_accesso.html',1,'']]],
  ['recordsalvataggio_1',['RecordSalvataggio',['../struct_record_salvataggio.html',1,'']]]
];
