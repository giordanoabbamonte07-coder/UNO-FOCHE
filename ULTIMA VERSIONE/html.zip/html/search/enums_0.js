var searchData=
[
  ['colore_0',['Colore',['../game_8h.html#a030035d63f7ea5baefdfe9a53844d27c',1,'game.h']]]
];
