var searchData=
[
  ['ottienicarta_0',['OttieniCarta',['../graphics_8c.html#ad959c3c570127ad6990032e946026d57',1,'graphics.c']]],
  ['ottieniposizionemazzogiocatore_1',['OttieniPosizioneMazzoGiocatore',['../game_8c.html#aa2bbfe121b559e821f99187c6733a282',1,'OttieniPosizioneMazzoGiocatore(int index, int num_giocatori):&#160;game.c'],['../game_8h.html#aa2bbfe121b559e821f99187c6733a282',1,'OttieniPosizioneMazzoGiocatore(int index, int num_giocatori):&#160;game.c']]],
  ['ottienistatisticheutente_2',['OttieniStatisticheUtente',['../archivio_8c.html#a5c1889226e8e84b71513037a0e889dab',1,'OttieniStatisticheUtente(const char *username, int *vittorie, int *sconfitte):&#160;archivio.c'],['../archivio_8h.html#a5c1889226e8e84b71513037a0e889dab',1,'OttieniStatisticheUtente(const char *username, int *vittorie, int *sconfitte):&#160;archivio.c']]]
];
