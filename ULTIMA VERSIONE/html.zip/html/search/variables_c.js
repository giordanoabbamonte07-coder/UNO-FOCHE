var searchData=
[
  ['scarto_0',['scarto',['../struct_partita.html#a4bdcf960cb54c6f5ffb563b3197905e4',1,'Partita']]],
  ['scegli_5fcolore_1',['scegli_colore',['../struct_partita.html#a3a15b8f271429b6e4f1b99b90f4cfafd',1,'Partita']]],
  ['sconfitteutente_2',['sconfitteUtente',['../main_8c.html#a19bd45f42e6bcc16d47956abde508bdb',1,'main.c']]],
  ['sfondo_3',['sfondo',['../struct_grafica.html#a90a2b678ce087c70623f1efbe51b84e9',1,'Grafica::sfondo'],['../struct_menu_grafica.html#a90a2b678ce087c70623f1efbe51b84e9',1,'MenuGrafica::sfondo'],['../struct_menu_scelta.html#a90a2b678ce087c70623f1efbe51b84e9',1,'MenuScelta::sfondo']]],
  ['sfondo_5faccedi_4',['sfondo_accedi',['../struct_menu_grafica.html#a1c775d69a90a31ae8cd25bbfdc077a21',1,'MenuGrafica']]],
  ['sfondo_5fregistrati_5',['sfondo_registrati',['../struct_menu_grafica.html#a26b54c15eaada7509f5633b7990d7303',1,'MenuGrafica']]],
  ['sfondoarchivio_6',['sfondoArchivio',['../struct_menu_scelta.html#a405580ddd2695c564e010c37a0cf946c',1,'MenuScelta']]],
  ['sfondoimpostazioni_7',['sfondoImpostazioni',['../struct_menu_scelta.html#a1a63dd53dbb19f730e3bbb2df16e1624',1,'MenuScelta']]],
  ['sfondoregole_8',['sfondoRegole',['../struct_menu_scelta.html#a34d8d56e5ada8aa78f31929d64bdf65f',1,'MenuScelta']]],
  ['sfondostatistiche_9',['sfondoStatistiche',['../archivio_8h.html#ac9da2322d5949840a7837a36348757e6',1,'sfondoStatistiche:&#160;main.c'],['../main_8c.html#ac9da2322d5949840a7837a36348757e6',1,'sfondoStatistiche:&#160;main.c']]],
  ['suono_5ffine_5fgiocato_10',['suono_fine_giocato',['../struct_partita.html#a3c40d34c7a997d99b242c96364f74c6d',1,'Partita']]]
];
