var searchData=
[
  ['nascondi_5farchivio_0',['nascondi_archivio',['../struct_menu_scelta.html#abb337ab7525ce78d81e90bcbbdbadc8f',1,'MenuScelta']]],
  ['nero_1',['NERO',['../game_8h.html#a030035d63f7ea5baefdfe9a53844d27ca40019d0f9c04951a840bde24c579e876',1,'game.h']]],
  ['nickname_2',['nickname',['../struct_record_salvataggio.html#a64be4233774119fecc2ecf04f0b490e4',1,'RecordSalvataggio::nickname'],['../struct_log_accesso.html#aa4466b4e778da008191fbde9c2eecee3',1,'LogAccesso::nickname'],['../struct_menu_grafica.html#a64be4233774119fecc2ecf04f0b490e4',1,'MenuGrafica::nickname'],['../struct_utente_registrato.html#aa4466b4e778da008191fbde9c2eecee3',1,'UtenteRegistrato::nickname']]],
  ['nomi_5fcolore_5fgfx_3',['nomi_colore_gfx',['../graphics_8c.html#a700c15569035e4b93942d36139c4732b',1,'graphics.c']]],
  ['nomi_5fcolori_5fita_4',['nomi_colori_ita',['../game_8c.html#a267ff02d706747f8c75e4b9a6de69411',1,'nomi_colori_ita:&#160;game.c'],['../game_8h.html#a267ff02d706747f8c75e4b9a6de69411',1,'nomi_colori_ita:&#160;game.c']]],
  ['note_20di_20manutenzione_5',['Note di manutenzione',['../md__r_e_a_d_m_e.html#autotoc_md21',1,'']]],
  ['num_5fcarte_6',['num_carte',['../struct_giocatore.html#aa333f9c5903d651051b9002f27d76826',1,'Giocatore']]],
  ['num_5fgiocatori_7',['num_giocatori',['../struct_partita.html#aab87f2ef6515c7a0c308ce7b7155b2f6',1,'Partita']]],
  ['num_5fscarto_8',['num_scarto',['../struct_partita.html#a981457a32f0ca95f8eb8c6b2206389d6',1,'Partita']]],
  ['numero_9',['NUMERO',['../game_8h.html#adbc6fd1c40bcc87f0ffb9a41a4a4155aa078d5d968b860a21dd1fd7682986e984',1,'game.h']]]
];
