var searchData=
[
  ['gestisceinput_0',['GestisceInput',['../game_8c.html#a425a6a4553385e952485f24b57faeff5',1,'GestisceInput(Partita *p):&#160;game.c'],['../game_8h.html#a425a6a4553385e952485f24b57faeff5',1,'GestisceInput(Partita *p):&#160;game.c']]],
  ['gestiscischermataauth_1',['GestisciSchermataAuth',['../menu_8c.html#aedaf59d96aedebada1c5aeed178097d9',1,'GestisciSchermataAuth(MenuGrafica *mg, StatoGioco stato):&#160;menu.c'],['../menu_8h.html#aedaf59d96aedebada1c5aeed178097d9',1,'GestisciSchermataAuth(MenuGrafica *mg, StatoGioco stato):&#160;menu.c']]],
  ['giocatorehamosse_2',['GiocatoreHaMosse',['../game_8c.html#a9b7733214ce574619e98b158c49e005e',1,'GiocatoreHaMosse(Partita *p, int id_giocatore):&#160;game.c'],['../game_8h.html#a9b7733214ce574619e98b158c49e005e',1,'GiocatoreHaMosse(Partita *p, int id_giocatore):&#160;game.c']]]
];
