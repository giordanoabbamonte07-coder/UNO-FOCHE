var searchData=
[
  ['valore_0',['valore',['../struct_carta.html#a303dfe0e1366c04c2e307a2536290f29',1,'Carta']]],
  ['vincitore_1',['vincitore',['../struct_partita.html#a3caa4013108a60a42b6a0394f36cb0dc',1,'Partita']]],
  ['vittorieutente_2',['vittorieUtente',['../main_8c.html#a6143e852a422f7a521b43f81705e976f',1,'main.c']]]
];
