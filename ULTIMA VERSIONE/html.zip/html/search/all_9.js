var searchData=
[
  ['logaccesso_0',['LogAccesso',['../struct_log_accesso.html',1,'']]]
];
