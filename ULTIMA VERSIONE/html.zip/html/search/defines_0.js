var searchData=
[
  ['carta_5faltezza_0',['CARTA_ALTEZZA',['../game_8h.html#a4cbcfaf3f2acf5c85d0d91eb928bf0cf',1,'CARTA_ALTEZZA:&#160;game.h'],['../graphics_8h.html#a4cbcfaf3f2acf5c85d0d91eb928bf0cf',1,'CARTA_ALTEZZA:&#160;graphics.h']]],
  ['carta_5flarghezza_1',['CARTA_LARGHEZZA',['../game_8h.html#a5f25862f5aaf31948e307f08d7fc9376',1,'CARTA_LARGHEZZA:&#160;game.h'],['../graphics_8h.html#a5f25862f5aaf31948e307f08d7fc9376',1,'CARTA_LARGHEZZA:&#160;graphics.h']]],
  ['colore_5ftesto_5fdata_2',['COLORE_TESTO_DATA',['../game_8h.html#aa54e9dcd9721049babd2c1cd469363de',1,'game.h']]],
  ['colore_5ftesto_5fevento_3',['COLORE_TESTO_EVENTO',['../game_8h.html#ab9297a173856fc545a0657edb2aaa680',1,'game.h']]]
];
