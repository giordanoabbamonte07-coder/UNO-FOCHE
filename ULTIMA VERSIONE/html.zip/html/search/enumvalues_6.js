var searchData=
[
  ['rosso_0',['ROSSO',['../game_8h.html#a030035d63f7ea5baefdfe9a53844d27caf31d451540fbe9019951dc44d57cada9',1,'game.h']]]
];
