var searchData=
[
  ['ultima_5fazione_0',['ultima_azione',['../struct_utente_registrato.html#ad0cea935d663716dccfe41a2bce92ec3',1,'UtenteRegistrato']]],
  ['ultimo_5faccesso_1',['ultimo_accesso',['../struct_utente_registrato.html#a052c445c8bdf4c20acb05f23af2c0938',1,'UtenteRegistrato']]],
  ['user_2',['user',['../struct_record_accesso.html#ab34a32fb3324f0fc33c8d7d44c46ebf9',1,'RecordAccesso']]],
  ['utente_5fcorrente_3',['utente_corrente',['../struct_partita.html#a874917103497e695431cd7dae1918f50',1,'Partita']]]
];
