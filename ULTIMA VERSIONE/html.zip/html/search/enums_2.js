var searchData=
[
  ['tipo_0',['Tipo',['../game_8h.html#adbc6fd1c40bcc87f0ffb9a41a4a4155a',1,'game.h']]]
];
