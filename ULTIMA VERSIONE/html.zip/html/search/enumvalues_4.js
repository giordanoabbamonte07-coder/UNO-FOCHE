var searchData=
[
  ['nero_0',['NERO',['../game_8h.html#a030035d63f7ea5baefdfe9a53844d27ca40019d0f9c04951a840bde24c579e876',1,'game.h']]],
  ['numero_1',['NUMERO',['../game_8h.html#adbc6fd1c40bcc87f0ffb9a41a4a4155aa078d5d968b860a21dd1fd7682986e984',1,'game.h']]]
];
