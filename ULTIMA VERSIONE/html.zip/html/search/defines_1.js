var searchData=
[
  ['mano_5fmax_0',['MANO_MAX',['../game_8h.html#a9badf708e62e4e95261605dae49b7f08',1,'game.h']]],
  ['max_5fsalvataggi_5fper_5futente_1',['MAX_SALVATAGGI_PER_UTENTE',['../archivio_8h.html#a7076962fd648c56cc26a4c638f8c93c3',1,'archivio.h']]],
  ['mazzo_5ftotale_2',['MAZZO_TOTALE',['../game_8h.html#a768cbc191f129e6802167a6cd8d6c7c7',1,'game.h']]]
];
