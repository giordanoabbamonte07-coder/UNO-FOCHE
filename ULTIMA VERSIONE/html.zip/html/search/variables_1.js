var searchData=
[
  ['blocco_5finput_0',['blocco_input',['../struct_partita.html#a0976fe72850a98f4678493bb8b74941f',1,'Partita']]],
  ['btn1vs1_1',['btn1vs1',['../struct_menu_scelta.html#ad453a6c3cea2453961384e50f09dce4d',1,'MenuScelta']]],
  ['btn_5faccedi_2',['btn_accedi',['../struct_menu_grafica.html#ace41d3a3497287bb566d8cf02b7caf43',1,'MenuGrafica']]],
  ['btn_5fospite_3',['btn_ospite',['../struct_menu_grafica.html#a319c92415b33fc3fbf8bdebd46b0dc6c',1,'MenuGrafica']]],
  ['btn_5fregistrati_4',['btn_registrati',['../struct_menu_grafica.html#a8f47806c53c861b1306a7524be286ac8',1,'MenuGrafica']]],
  ['btn_5fsospendi_5',['btn_sospendi',['../struct_grafica.html#a43afa14845e66de51023427d72f498e5',1,'Grafica']]],
  ['btnarchivio_6',['btnArchivio',['../struct_menu_scelta.html#a456188d82f0c19697d93da7ec149ce31',1,'MenuScelta']]],
  ['btnavanti_7',['btnAvanti',['../archivio_8h.html#ae16ceed85cbf05cc67bca1125b253d3a',1,'btnAvanti:&#160;main.c'],['../main_8c.html#ae16ceed85cbf05cc67bca1125b253d3a',1,'btnAvanti:&#160;main.c']]],
  ['btnimpostazioni_8',['btnImpostazioni',['../struct_menu_scelta.html#af94685c15b48845024157619de8126c9',1,'MenuScelta']]],
  ['btnindietro_9',['btnIndietro',['../struct_menu_scelta.html#a4c42545da65859b4ed64c59a50e54317',1,'MenuScelta::btnIndietro'],['../archivio_8h.html#a4c42545da65859b4ed64c59a50e54317',1,'btnIndietro:&#160;main.c'],['../main_8c.html#a4c42545da65859b4ed64c59a50e54317',1,'btnIndietro:&#160;main.c']]],
  ['btnmulti_10',['btnMulti',['../struct_menu_scelta.html#a0e25543aeba0fb2ebfb6c1f2c6b62ae4',1,'MenuScelta']]],
  ['btnoff_11',['btnOff',['../struct_menu_scelta.html#a68c12c165dc8ac1f1667a23fd3bd7011',1,'MenuScelta']]],
  ['btnonaudio_12',['btnOnAudio',['../struct_menu_scelta.html#a25f68ee74d44581391dbd44d6f6bb7f5',1,'MenuScelta']]],
  ['btnonmusica_13',['btnOnMusica',['../struct_menu_scelta.html#aa1675a6e58a72ae9d72ae9684e84da59',1,'MenuScelta']]],
  ['btnregole_14',['btnRegole',['../struct_menu_scelta.html#a1d6d1c40b11e499d0f263339b168d3ab',1,'MenuScelta']]]
];
