var searchData=
[
  ['e_20dipendenze_0',['Tecnologie e dipendenze',['../md__r_e_a_d_m_e.html#autotoc_md2',1,'']]],
  ['ed_20esecuzione_1',['Compilazione ed esecuzione',['../md__r_e_a_d_m_e.html#autotoc_md3',1,'']]],
  ['eliminapartitadaarchivio_2',['EliminaPartitaDaArchivio',['../archivio_8c.html#a4bcf966145e0aee2e1064a7768b3d350',1,'EliminaPartitaDaArchivio(const char *username, int indiceDaRimuovere):&#160;archivio.c'],['../archivio_8h.html#a4bcf966145e0aee2e1064a7768b3d350',1,'EliminaPartitaDaArchivio(const char *username, int indiceDaRimuovere):&#160;archivio.c']]],
  ['esecuzione_3',['Compilazione ed esecuzione',['../md__r_e_a_d_m_e.html#autotoc_md3',1,'']]],
  ['evidenziacarta_4',['EvidenziaCarta',['../graphics_8c.html#a8e5d8ee21a78ad39eadc32b7500effbf',1,'graphics.c']]]
];
