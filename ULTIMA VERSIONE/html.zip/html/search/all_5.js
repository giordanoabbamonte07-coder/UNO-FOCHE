var searchData=
[
  ['file_20dati_20generati_20o_20usati_0',['File dati generati o usati',['../md__r_e_a_d_m_e.html#autotoc_md19',1,'']]],
  ['file_20principali_20da_20consultare_1',['File principali da consultare',['../md__r_e_a_d_m_e.html#autotoc_md23',1,'']]],
  ['fine_5fanimazione_2',['fine_animazione',['../struct_partita.html#a780a2761919018814b6f23dff43e2e3f',1,'Partita']]],
  ['flusso_20generale_20dell_20applicazione_3',['Flusso generale dell&apos;applicazione',['../md__r_e_a_d_m_e.html#autotoc_md5',1,'']]],
  ['flusso_20tipico_20di_20gioco_4',['Flusso tipico di gioco',['../md__r_e_a_d_m_e.html#autotoc_md22',1,'']]],
  ['foca_5',['foca',['../struct_grafica.html#ae0f4487faa5699f6f1c881698b2219ed',1,'Grafica']]],
  ['foca_20documentazione_20del_20codice_6',['UNO Foca - Documentazione del codice',['../md__r_e_a_d_m_e.html',1,'']]],
  ['frame_5fcounter_7',['frame_counter',['../struct_menu_grafica.html#a314b72c8b8d68e6dbc30c4d374912519',1,'MenuGrafica']]],
  ['funzioni_20principali_8',['Funzioni principali',['../md__r_e_a_d_m_e.html#autotoc_md8',1,'']]]
];
