var searchData=
[
  ['ultima_5fazione_0',['ultima_azione',['../struct_utente_registrato.html#ad0cea935d663716dccfe41a2bce92ec3',1,'UtenteRegistrato']]],
  ['ultimo_5faccesso_1',['ultimo_accesso',['../struct_utente_registrato.html#a052c445c8bdf4c20acb05f23af2c0938',1,'UtenteRegistrato']]],
  ['uno_20foca_20documentazione_20del_20codice_2',['UNO Foca - Documentazione del codice',['../md__r_e_a_d_m_e.html',1,'']]],
  ['updateaudio_3',['UpdateAudio',['../audio_8c.html#aa55afe391362b8ee65cf6b504117ed2f',1,'UpdateAudio(void):&#160;audio.c'],['../audio_8h.html#aa55afe391362b8ee65cf6b504117ed2f',1,'UpdateAudio(void):&#160;audio.c']]],
  ['usati_4',['File dati generati o usati',['../md__r_e_a_d_m_e.html#autotoc_md19',1,'']]],
  ['user_5',['user',['../struct_record_accesso.html#ab34a32fb3324f0fc33c8d7d44c46ebf9',1,'RecordAccesso']]],
  ['utente_6',['Dati utente',['../md__r_e_a_d_m_e.html#autotoc_md13',1,'']]],
  ['utente_5fcorrente_7',['utente_corrente',['../struct_partita.html#a874917103497e695431cd7dae1918f50',1,'Partita']]],
  ['utenteregistrato_8',['UtenteRegistrato',['../struct_utente_registrato.html',1,'']]]
];
