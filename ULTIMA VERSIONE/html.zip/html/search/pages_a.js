var searchData=
[
  ['panoramica_0',['Panoramica',['../md__r_e_a_d_m_e.html#autotoc_md1',1,'']]],
  ['principali_1',['principali',['../md__r_e_a_d_m_e.html#autotoc_md8',1,'Funzioni principali'],['../md__r_e_a_d_m_e.html#autotoc_md7',1,'Strutture principali']]],
  ['principali_20da_20consultare_2',['File principali da consultare',['../md__r_e_a_d_m_e.html#autotoc_md23',1,'']]],
  ['progetto_3',['Struttura del progetto',['../md__r_e_a_d_m_e.html#autotoc_md4',1,'']]]
];
