var searchData=
[
  ['main_2ec_0',['main.c',['../main_8c.html',1,'']]],
  ['menu_2ec_1',['menu.c',['../menu_8c.html',1,'']]],
  ['menu_2eh_2',['menu.h',['../menu_8h.html',1,'']]],
  ['menu_5fscelta_2ec_3',['menu_scelta.c',['../menu__scelta_8c.html',1,'']]],
  ['menu_5fscelta_2eh_4',['menu_scelta.h',['../menu__scelta_8h.html',1,'']]]
];
