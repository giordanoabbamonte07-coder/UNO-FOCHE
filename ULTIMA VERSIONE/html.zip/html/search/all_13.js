var searchData=
[
  ['whitehall_5fmode_0',['Whitehall_mode',['../struct_partita.html#a488564cbbaca1d6961dfbd57597acd4e',1,'Partita']]],
  ['win_5fimg_1',['win_img',['../struct_grafica.html#a678afc15010a3bf2c56c8ffcf5502b7c',1,'Grafica']]]
];
