var searchData=
[
  ['salta_0',['SALTA',['../game_8h.html#adbc6fd1c40bcc87f0ffb9a41a4a4155aa150773ba1df9e1914be905e7fcd09a4b',1,'game.h']]],
  ['stato_5faccedi_1',['STATO_ACCEDI',['../menu_8h.html#a9e7662a03c3966203757e9c0186bd354aece4d3ebaf169eeb79486e97f740a164',1,'menu.h']]],
  ['stato_5farchivio_2',['STATO_ARCHIVIO',['../menu_8h.html#a9e7662a03c3966203757e9c0186bd354a7abda57556cf863f1618afbb6ddb6e47',1,'menu.h']]],
  ['stato_5fdebug_3',['STATO_DEBUG',['../menu_8h.html#a9e7662a03c3966203757e9c0186bd354a7293663360468110a75221cd700ce0f7',1,'menu.h']]],
  ['stato_5fgioco_4',['STATO_GIOCO',['../menu_8h.html#a9e7662a03c3966203757e9c0186bd354aa1eda7dce686f88eaa8ce8344e31af4a',1,'menu.h']]],
  ['stato_5fimpostazioni_5',['STATO_IMPOSTAZIONI',['../menu_8h.html#a9e7662a03c3966203757e9c0186bd354a69f72c9f888b2a4c171c875a5ee9d525',1,'menu.h']]],
  ['stato_5fmenu_6',['STATO_MENU',['../menu_8h.html#a9e7662a03c3966203757e9c0186bd354afd452cc56d1447dfe216245859c0f8f8',1,'menu.h']]],
  ['stato_5fmenu_5fscelta_7',['STATO_MENU_SCELTA',['../menu_8h.html#a9e7662a03c3966203757e9c0186bd354ad020e04077c0923289310174fb456c70',1,'menu.h']]],
  ['stato_5fregistrati_8',['STATO_REGISTRATI',['../menu_8h.html#a9e7662a03c3966203757e9c0186bd354aefe875b4f1fe2f8f7064a783bb097fd1',1,'menu.h']]],
  ['stato_5fregole_9',['STATO_REGOLE',['../menu_8h.html#a9e7662a03c3966203757e9c0186bd354abd208c7da89cb3d93a809eb8efd854d7',1,'menu.h']]],
  ['stato_5fstatistiche_10',['STATO_STATISTICHE',['../menu_8h.html#a9e7662a03c3966203757e9c0186bd354a6cd1163aa7d278fdaecc1e919eaa9afc',1,'menu.h']]]
];
