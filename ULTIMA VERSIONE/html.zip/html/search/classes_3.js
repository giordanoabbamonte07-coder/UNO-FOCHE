var searchData=
[
  ['menugrafica_0',['MenuGrafica',['../struct_menu_grafica.html',1,'']]],
  ['menuscelta_1',['MenuScelta',['../struct_menu_scelta.html',1,'']]]
];
