var searchData=
[
  ['deinizializzamenuscelta_0',['DeinizializzaMenuScelta',['../menu__scelta_8c.html#a3a6e4fc29b651931c6b88fa43c8b04db',1,'DeinizializzaMenuScelta(MenuScelta *menu):&#160;menu_scelta.c'],['../menu__scelta_8h.html#a3a6e4fc29b651931c6b88fa43c8b04db',1,'DeinizializzaMenuScelta(MenuScelta *menu):&#160;menu_scelta.c']]],
  ['disegnaarchiviostorico_1',['DisegnaArchivioStorico',['../archivio_8c.html#a0a97c89f0e9c7d9e2bab78f222950aca',1,'DisegnaArchivioStorico(const char *username, Vector2 mousePos, int *partitaSelezionataIndice):&#160;archivio.c'],['../archivio_8h.html#a0a97c89f0e9c7d9e2bab78f222950aca',1,'DisegnaArchivioStorico(const char *username, Vector2 mousePos, int *partitaSelezionataIndice):&#160;archivio.c']]],
  ['disegnacarta_2',['DisegnaCarta',['../graphics_8c.html#adffc6d1ec2312f9f68b3f15395e811f7',1,'graphics.c']]],
  ['disegnapartita_3',['DisegnaPartita',['../graphics_8c.html#af80ef27d7924e3e196fb780c38d31af1',1,'DisegnaPartita(Grafica *gfx, Partita *p):&#160;graphics.c'],['../graphics_8h.html#af80ef27d7924e3e196fb780c38d31af1',1,'DisegnaPartita(Grafica *gfx, Partita *p):&#160;graphics.c']]],
  ['disegnatestopixelgrassetto_4',['DisegnaTestoPixelGrassetto',['../graphics_8c.html#a7b41d6447819a799f28ec26a8ee65d9b',1,'DisegnaTestoPixelGrassetto(const char *testo, int x, int y, int fontSize, Color baseColor):&#160;graphics.c'],['../graphics_8h.html#a7b41d6447819a799f28ec26a8ee65d9b',1,'DisegnaTestoPixelGrassetto(const char *testo, int x, int y, int fontSize, Color baseColor):&#160;graphics.c']]]
];
