var searchData=
[
  ['campo_5fattivo_0',['campo_attivo',['../struct_menu_grafica.html#a7b271356cc5af1fadbde0ce4847077f2',1,'MenuGrafica']]],
  ['carta_5fanimata_1',['carta_animata',['../struct_partita.html#a28c4e281c43e465398d2ffa86c34c631',1,'Partita']]],
  ['carte_2',['carte',['../struct_grafica.html#a7c627bd1fe9469884fad0c4869256288',1,'Grafica']]],
  ['carte_5fmazzo_3',['carte_mazzo',['../struct_partita.html#a8ea544ae6f684427e48fd6a141285c23',1,'Partita']]],
  ['cima_4',['cima',['../struct_partita.html#a849deaf3d237be3cae4eaa02a273283c',1,'Partita']]],
  ['colore_5',['colore',['../struct_carta.html#a489426ff15ee3d43b4fa14d4760cb232',1,'Carta']]],
  ['colore_5fattuale_6',['colore_attuale',['../struct_partita.html#afe86c59bf78fa43d5d9fd2cb509adda7',1,'Partita']]]
];
