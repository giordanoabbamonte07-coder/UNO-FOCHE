var searchData=
[
  ['giocatori_0',['giocatori',['../struct_partita.html#a87b92ab4bf8a1caf7da7bdde4818e48b',1,'Partita']]]
];
