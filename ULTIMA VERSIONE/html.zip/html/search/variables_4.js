var searchData=
[
  ['fine_5fanimazione_0',['fine_animazione',['../struct_partita.html#a780a2761919018814b6f23dff43e2e3f',1,'Partita']]],
  ['foca_1',['foca',['../struct_grafica.html#ae0f4487faa5699f6f1c881698b2219ed',1,'Grafica']]],
  ['frame_5fcounter_2',['frame_counter',['../struct_menu_grafica.html#a314b72c8b8d68e6dbc30c4d374912519',1,'MenuGrafica']]]
];
