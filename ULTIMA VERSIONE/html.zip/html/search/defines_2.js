var searchData=
[
  ['schermo_5faltezza_0',['SCHERMO_ALTEZZA',['../game_8h.html#af98d217b28f157b70acf74bdc4c7e021',1,'SCHERMO_ALTEZZA:&#160;game.h'],['../menu__scelta_8c.html#af98d217b28f157b70acf74bdc4c7e021',1,'SCHERMO_ALTEZZA:&#160;menu_scelta.c']]],
  ['schermo_5flarghezza_1',['SCHERMO_LARGHEZZA',['../game_8h.html#a5944cd052f21977cdd5318d16f067178',1,'SCHERMO_LARGHEZZA:&#160;game.h'],['../menu__scelta_8c.html#a5944cd052f21977cdd5318d16f067178',1,'SCHERMO_LARGHEZZA:&#160;menu_scelta.c']]],
  ['stato_5fmenu_5fscelta_5fcorrente_2',['STATO_MENU_SCELTA_CORRENTE',['../menu__scelta_8h.html#a0d9b8b381264683154f440260c58cca9',1,'menu_scelta.h']]]
];
