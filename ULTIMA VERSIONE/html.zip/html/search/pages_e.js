var searchData=
[
  ['uno_20foca_20documentazione_20del_20codice_0',['UNO Foca - Documentazione del codice',['../md__r_e_a_d_m_e.html',1,'']]],
  ['usati_1',['File dati generati o usati',['../md__r_e_a_d_m_e.html#autotoc_md19',1,'']]],
  ['utente_2',['Dati utente',['../md__r_e_a_d_m_e.html#autotoc_md13',1,'']]]
];
