var searchData=
[
  ['mano_0',['mano',['../struct_giocatore.html#a8edfe5e592f246e047d9722698b536e9',1,'Giocatore']]],
  ['mazzo_1',['mazzo',['../struct_partita.html#ac434c2e2a332a78dd4853f29fb400ffc',1,'Partita']]],
  ['messaggio_2',['messaggio',['../struct_partita.html#a1546579b308d848dbacc1e1d227751a6',1,'Partita']]],
  ['musicaattiva_3',['musicaAttiva',['../struct_menu_scelta.html#ab63dc697317aeba787c28309b27e9431',1,'MenuScelta']]]
];
