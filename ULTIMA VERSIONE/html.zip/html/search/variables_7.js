var searchData=
[
  ['indice_5fmazzo_0',['indice_mazzo',['../struct_partita.html#abee02839bb454f464877dee4e1fc8462',1,'Partita']]],
  ['inizio_5fanimazione_1',['inizio_animazione',['../struct_partita.html#a810690171fc829db75154a6402a36528',1,'Partita']]],
  ['is_5fguest_2',['is_guest',['../struct_partita.html#a11c3978f3a78b86b5a8ecf77ee15a189',1,'Partita']]]
];
