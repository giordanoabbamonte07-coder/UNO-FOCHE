var searchData=
[
  ['statogioco_0',['StatoGioco',['../menu_8h.html#a9e7662a03c3966203757e9c0186bd354',1,'menu.h']]]
];
