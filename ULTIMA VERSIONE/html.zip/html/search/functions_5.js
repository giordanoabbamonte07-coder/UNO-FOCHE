var searchData=
[
  ['impostastatoeffetti_0',['ImpostaStatoEffetti',['../audio_8c.html#abfd4b86126de797ff51b88f8dcf87f87',1,'ImpostaStatoEffetti(bool attiva):&#160;audio.c'],['../audio_8h.html#abfd4b86126de797ff51b88f8dcf87f87',1,'ImpostaStatoEffetti(bool attiva):&#160;audio.c']]],
  ['impostastatomusica_1',['ImpostaStatoMusica',['../audio_8c.html#a34f61171aedc721009397790e6dbb0df',1,'ImpostaStatoMusica(bool attiva):&#160;audio.c'],['../audio_8h.html#a34f61171aedc721009397790e6dbb0df',1,'ImpostaStatoMusica(bool attiva):&#160;audio.c']]],
  ['initaudio_2',['InitAudio',['../audio_8c.html#a54d939106d7dd8bd3c4d00ca817e4d25',1,'InitAudio(void):&#160;audio.c'],['../audio_8h.html#a54d939106d7dd8bd3c4d00ca817e4d25',1,'InitAudio(void):&#160;audio.c']]],
  ['inizializzagrafica_3',['InizializzaGrafica',['../graphics_8c.html#a1a1f999ac837e2860330667c594bfc48',1,'InizializzaGrafica(Grafica *gfx):&#160;graphics.c'],['../graphics_8h.html#a1a1f999ac837e2860330667c594bfc48',1,'InizializzaGrafica(Grafica *gfx):&#160;graphics.c']]],
  ['inizializzamenu_4',['InizializzaMenu',['../menu_8c.html#a784d0026d039ae89a37b76bb9cb93c65',1,'InizializzaMenu(MenuGrafica *mg):&#160;menu.c'],['../menu_8h.html#a784d0026d039ae89a37b76bb9cb93c65',1,'InizializzaMenu(MenuGrafica *mg):&#160;menu.c']]],
  ['inizializzamenuscelta_5',['InizializzaMenuScelta',['../menu__scelta_8c.html#ab3588acfa6e1da1846ff4dd90a605003',1,'InizializzaMenuScelta(MenuScelta *menu):&#160;menu_scelta.c'],['../menu__scelta_8h.html#ab3588acfa6e1da1846ff4dd90a605003',1,'InizializzaMenuScelta(MenuScelta *menu):&#160;menu_scelta.c']]],
  ['inizializzapartita_6',['InizializzaPartita',['../game_8c.html#a21fda4568f808bf067671e3b008bfd3d',1,'InizializzaPartita(Partita *p, int num_giocatori):&#160;game.c'],['../game_8h.html#a21fda4568f808bf067671e3b008bfd3d',1,'InizializzaPartita(Partita *p, int num_giocatori):&#160;game.c']]],
  ['inizializzarisorsearchivio_7',['InizializzaRisorseArchivio',['../archivio_8c.html#a55712d53701eaf266a8c7cd6dbc59cdd',1,'InizializzaRisorseArchivio(void):&#160;archivio.c'],['../archivio_8h.html#a55712d53701eaf266a8c7cd6dbc59cdd',1,'InizializzaRisorseArchivio(void):&#160;archivio.c']]]
];
