var searchData=
[
  ['partita_0',['Partita',['../struct_partita.html',1,'']]]
];
