var searchData=
[
  ['pesca_0',['Pesca',['../game_8c.html#af3097c1c42b9872b194d5fc7b45c43e7',1,'Pesca(Partita *p):&#160;game.c'],['../game_8h.html#af3097c1c42b9872b194d5fc7b45c43e7',1,'Pesca(Partita *p):&#160;game.c']]],
  ['playbackgroundmusic_1',['PlayBackgroundMusic',['../audio_8c.html#aa0b52ffc919e93ab9420be04885f9aa6',1,'PlayBackgroundMusic(void):&#160;audio.c'],['../audio_8h.html#aa0b52ffc919e93ab9420be04885f9aa6',1,'PlayBackgroundMusic(void):&#160;audio.c']]],
  ['playcardsound_2',['PlayCardSound',['../audio_8c.html#a0a8382ceeead4f700d51fe4048e740bc',1,'PlayCardSound(void):&#160;audio.c'],['../audio_8h.html#a0a8382ceeead4f700d51fe4048e740bc',1,'PlayCardSound(void):&#160;audio.c']]],
  ['playdefeatsound_3',['PlayDefeatSound',['../audio_8c.html#a5b056503149723e47e3c4a9fbb916c4e',1,'PlayDefeatSound(void):&#160;audio.c'],['../audio_8h.html#a5b056503149723e47e3c4a9fbb916c4e',1,'PlayDefeatSound(void):&#160;audio.c']]],
  ['playwinsound_4',['PlayWinSound',['../audio_8c.html#ab43514d467398d38042f3eaea35cf500',1,'PlayWinSound(void):&#160;audio.c'],['../audio_8h.html#ab43514d467398d38042f3eaea35cf500',1,'PlayWinSound(void):&#160;audio.c']]],
  ['preparaarchiviostorico_5',['PreparaArchivioStorico',['../archivio_8c.html#aac875619d353e8f9f4c6087c7efa283d',1,'PreparaArchivioStorico(const char *username):&#160;archivio.c'],['../archivio_8h.html#aac875619d353e8f9f4c6087c7efa283d',1,'PreparaArchivioStorico(const char *username):&#160;archivio.c']]],
  ['puogiocare_6',['PuoGiocare',['../game_8c.html#ab94485366daa9626d19bb5b74b5f1e29',1,'PuoGiocare(Carta c, Partita *p):&#160;game.c'],['../game_8h.html#ab94485366daa9626d19bb5b74b5f1e29',1,'PuoGiocare(Carta c, Partita *p):&#160;game.c']]]
];
