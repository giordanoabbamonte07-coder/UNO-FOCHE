var searchData=
[
  ['giallo_0',['GIALLO',['../game_8h.html#a030035d63f7ea5baefdfe9a53844d27cab43fc5129914206a77c76e0cffd20df2',1,'game.h']]]
];
