var searchData=
[
  ['vai_5f1vs1_0',['VAI_1VS1',['../menu__scelta_8h.html#a496810aba8c641824ff194cc1a8d0019',1,'menu_scelta.h']]],
  ['vai_5farchivio_1',['VAI_ARCHIVIO',['../menu__scelta_8h.html#a98cff792e2069ed18baa47f4c1fe595d',1,'menu_scelta.h']]],
  ['vai_5fimpostazioni_2',['VAI_IMPOSTAZIONI',['../menu__scelta_8h.html#a91b43b6674fca50a5664b29fcba5b05e',1,'menu_scelta.h']]],
  ['vai_5findietro_3',['VAI_INDIETRO',['../menu__scelta_8h.html#a570b56abe9045f6ef57a9bc3705caa84',1,'menu_scelta.h']]],
  ['vai_5fmultigiocatore_4',['VAI_MULTIGIOCATORE',['../menu__scelta_8h.html#ab8c21e22ebac4b86a10a70f27139d1fa',1,'menu_scelta.h']]],
  ['vai_5fregole_5',['VAI_REGOLE',['../menu__scelta_8h.html#acdc7329b766c4a8af8cdff608bdf2dce',1,'menu_scelta.h']]],
  ['valore_6',['valore',['../struct_carta.html#a303dfe0e1366c04c2e307a2536290f29',1,'Carta']]],
  ['verde_7',['VERDE',['../game_8h.html#a030035d63f7ea5baefdfe9a53844d27caf9efd9e6bd17c0580d8a0432ba1b04a2',1,'game.h']]],
  ['vincitore_8',['vincitore',['../struct_partita.html#a3caa4013108a60a42b6a0394f36cb0dc',1,'Partita']]],
  ['vittorieutente_9',['vittorieUtente',['../main_8c.html#a6143e852a422f7a521b43f81705e976f',1,'main.c']]]
];
