var searchData=
[
  ['anima_5fdeltaplano_0',['anima_deltaplano',['../struct_partita.html#a1c8606f3e39535406ab2dd5808cf794d',1,'Partita']]],
  ['anima_5ffoca_1',['anima_foca',['../struct_partita.html#a7de6722b52cec12463ce1d3f43591793',1,'Partita']]],
  ['animando_2',['animando',['../struct_partita.html#ab002f83d9640e8dc3386e97748cda3fc',1,'Partita']]],
  ['audioattivo_3',['audioAttivo',['../struct_menu_scelta.html#a85d889be71e939ea2d0582d8e112073e',1,'MenuScelta']]],
  ['azione_4',['azione',['../struct_record_accesso.html#a1a51a5d930bd53beae10cfe8bd0baf58',1,'RecordAccesso']]]
];
