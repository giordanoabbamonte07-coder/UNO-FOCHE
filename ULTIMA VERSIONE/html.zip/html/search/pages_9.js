var searchData=
[
  ['o_20usati_0',['File dati generati o usati',['../md__r_e_a_d_m_e.html#autotoc_md19',1,'']]]
];
