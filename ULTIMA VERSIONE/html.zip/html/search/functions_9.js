var searchData=
[
  ['salvapartita_0',['SalvaPartita',['../game_8c.html#acbae787be923d1daedbc25bb09910403',1,'game.c']]],
  ['salvapartitasospesa_1',['SalvaPartitaSospesa',['../archivio_8c.html#af8d26044be1ee4d4819311d8ea786576',1,'SalvaPartitaSospesa(Partita *partitaCorrente):&#160;archivio.c'],['../archivio_8h.html#af8d26044be1ee4d4819311d8ea786576',1,'SalvaPartitaSospesa(Partita *partitaCorrente):&#160;archivio.c']]],
  ['salvarisultatopartita_2',['SalvaRisultatoPartita',['../archivio_8c.html#a25074f360d01d5d6451ed7206b9f282e',1,'SalvaRisultatoPartita(const char *username, bool haVinto):&#160;archivio.c'],['../archivio_8h.html#a25074f360d01d5d6451ed7206b9f282e',1,'SalvaRisultatoPartita(const char *username, bool haVinto):&#160;archivio.c']]],
  ['scaricagrafica_3',['ScaricaGrafica',['../graphics_8c.html#acf092cde69a7326412b8967851c26b8e',1,'ScaricaGrafica(Grafica *gfx):&#160;graphics.c'],['../graphics_8h.html#acf092cde69a7326412b8967851c26b8e',1,'ScaricaGrafica(Grafica *gfx):&#160;graphics.c']]],
  ['scaricamenu_4',['ScaricaMenu',['../menu_8c.html#acdb1b7396af9f3b617830c37bc9d5bb6',1,'ScaricaMenu(MenuGrafica *mg):&#160;menu.c'],['../menu_8h.html#acdb1b7396af9f3b617830c37bc9d5bb6',1,'ScaricaMenu(MenuGrafica *mg):&#160;menu.c']]],
  ['scaricarisorsearchivio_5',['ScaricaRisorseArchivio',['../archivio_8c.html#a1e0acc9358a505da02f123c0d12eb562',1,'ScaricaRisorseArchivio(void):&#160;archivio.c'],['../archivio_8h.html#a1e0acc9358a505da02f123c0d12eb562',1,'ScaricaRisorseArchivio(void):&#160;archivio.c']]],
  ['scrivilogaccessobinario_6',['ScriviLogAccessoBinario',['../main_8c.html#afbc3ace6d281344b83da278db922e505',1,'main.c']]],
  ['stopbackgroundmusic_7',['StopBackgroundMusic',['../audio_8c.html#ac4ebc62c11c1cce00580c03e2c4dbcca',1,'StopBackgroundMusic(void):&#160;audio.c'],['../audio_8h.html#ac4ebc62c11c1cce00580c03e2c4dbcca',1,'StopBackgroundMusic(void):&#160;audio.c']]]
];
