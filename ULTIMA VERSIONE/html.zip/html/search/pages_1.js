var searchData=
[
  ['codice_0',['UNO Foca - Documentazione del codice',['../md__r_e_a_d_m_e.html',1,'']]],
  ['compilazione_20ed_20esecuzione_1',['Compilazione ed esecuzione',['../md__r_e_a_d_m_e.html#autotoc_md3',1,'']]],
  ['consultare_2',['File principali da consultare',['../md__r_e_a_d_m_e.html#autotoc_md23',1,'']]]
];
