var searchData=
[
  ['ha_5fnotificato_5fultima_0',['ha_notificato_ultima',['../struct_giocatore.html#ae53b58247060acddcec8991a3f6e7f54',1,'Giocatore']]],
  ['ha_5fpescato_1',['ha_pescato',['../struct_partita.html#a3d121a660725818ea037682ec8ac0665',1,'Partita']]]
];
