var searchData=
[
  ['implementate_0',['Regole implementate',['../md__r_e_a_d_m_e.html#autotoc_md9',1,'']]]
];
