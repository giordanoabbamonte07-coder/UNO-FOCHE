var searchData=
[
  ['salvataggi_0',['Salvataggi',['../md__r_e_a_d_m_e.html#autotoc_md17',1,'']]],
  ['statistiche_1',['Statistiche',['../md__r_e_a_d_m_e.html#autotoc_md18',1,'']]],
  ['struttura_20del_20progetto_2',['Struttura del progetto',['../md__r_e_a_d_m_e.html#autotoc_md4',1,'']]],
  ['strutture_20principali_3',['Strutture principali',['../md__r_e_a_d_m_e.html#autotoc_md7',1,'']]]
];
