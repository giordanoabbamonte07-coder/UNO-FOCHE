var searchData=
[
  ['panoramica_0',['Panoramica',['../md__r_e_a_d_m_e.html#autotoc_md1',1,'']]],
  ['partita_1',['Partita',['../struct_partita.html',1,'']]],
  ['partita_5ffinita_2',['partita_finita',['../struct_partita.html#add026eaab4c5437233432e20ac2764ec',1,'Partita']]],
  ['pass_3',['pass',['../struct_record_accesso.html#ade137af880b61e4c68fb2dcc274dd1c0',1,'RecordAccesso']]],
  ['password_4',['password',['../struct_log_accesso.html#a31e8e8d75a558616beda2db0705befb4',1,'LogAccesso::password'],['../struct_menu_grafica.html#a9ff5f387df67f4aa7fed563cd905bce8',1,'MenuGrafica::password'],['../struct_utente_registrato.html#a31e8e8d75a558616beda2db0705befb4',1,'UtenteRegistrato::password']]],
  ['pesca_5',['Pesca',['../game_8c.html#af3097c1c42b9872b194d5fc7b45c43e7',1,'Pesca(Partita *p):&#160;game.c'],['../game_8h.html#af3097c1c42b9872b194d5fc7b45c43e7',1,'Pesca(Partita *p):&#160;game.c']]],
  ['piu_5fdue_6',['PIU_DUE',['../game_8h.html#adbc6fd1c40bcc87f0ffb9a41a4a4155aa581bd7682ee49c6ef2aed15703e34491',1,'game.h']]],
  ['piu_5fquattro_7',['PIU_QUATTRO',['../game_8h.html#adbc6fd1c40bcc87f0ffb9a41a4a4155aafca5f3472b00061a1859b891565b1bc4',1,'game.h']]],
  ['playbackgroundmusic_8',['PlayBackgroundMusic',['../audio_8c.html#aa0b52ffc919e93ab9420be04885f9aa6',1,'PlayBackgroundMusic(void):&#160;audio.c'],['../audio_8h.html#aa0b52ffc919e93ab9420be04885f9aa6',1,'PlayBackgroundMusic(void):&#160;audio.c']]],
  ['playcardsound_9',['PlayCardSound',['../audio_8c.html#a0a8382ceeead4f700d51fe4048e740bc',1,'PlayCardSound(void):&#160;audio.c'],['../audio_8h.html#a0a8382ceeead4f700d51fe4048e740bc',1,'PlayCardSound(void):&#160;audio.c']]],
  ['playdefeatsound_10',['PlayDefeatSound',['../audio_8c.html#a5b056503149723e47e3c4a9fbb916c4e',1,'PlayDefeatSound(void):&#160;audio.c'],['../audio_8h.html#a5b056503149723e47e3c4a9fbb916c4e',1,'PlayDefeatSound(void):&#160;audio.c']]],
  ['playwinsound_11',['PlayWinSound',['../audio_8c.html#ab43514d467398d38042f3eaea35cf500',1,'PlayWinSound(void):&#160;audio.c'],['../audio_8h.html#ab43514d467398d38042f3eaea35cf500',1,'PlayWinSound(void):&#160;audio.c']]],
  ['pos_5fx_5fdeltaplano_12',['pos_x_deltaplano',['../struct_partita.html#a14ff56c7e9bbd7a50dab3f392646b01e',1,'Partita']]],
  ['posizione_5fanimazione_13',['posizione_animazione',['../struct_partita.html#a6d9cea2ee169eeeb3b6d25a5d6e05835',1,'Partita']]],
  ['preparaarchiviostorico_14',['PreparaArchivioStorico',['../archivio_8c.html#aac875619d353e8f9f4c6087c7efa283d',1,'PreparaArchivioStorico(const char *username):&#160;archivio.c'],['../archivio_8h.html#aac875619d353e8f9f4c6087c7efa283d',1,'PreparaArchivioStorico(const char *username):&#160;archivio.c']]],
  ['principali_15',['principali',['../md__r_e_a_d_m_e.html#autotoc_md8',1,'Funzioni principali'],['../md__r_e_a_d_m_e.html#autotoc_md7',1,'Strutture principali']]],
  ['principali_20da_20consultare_16',['File principali da consultare',['../md__r_e_a_d_m_e.html#autotoc_md23',1,'']]],
  ['progetto_17',['Struttura del progetto',['../md__r_e_a_d_m_e.html#autotoc_md4',1,'']]],
  ['prossimo_5fturno_18',['prossimo_turno',['../struct_partita.html#a0eed4afe8bd32bfebf539585bbb70b1a',1,'Partita']]],
  ['puo_5fpassare_19',['puo_passare',['../struct_partita.html#a1857acff64dd9b26571d17c66bba5add',1,'Partita']]],
  ['puogiocare_20',['PuoGiocare',['../game_8c.html#ab94485366daa9626d19bb5b74b5f1e29',1,'PuoGiocare(Carta c, Partita *p):&#160;game.c'],['../game_8h.html#ab94485366daa9626d19bb5b74b5f1e29',1,'PuoGiocare(Carta c, Partita *p):&#160;game.c']]]
];
