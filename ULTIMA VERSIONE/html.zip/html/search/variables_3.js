var searchData=
[
  ['da_5fgiocatore_0',['da_giocatore',['../struct_partita.html#aeb7e941b59ee7ed7c3e2978ccb09845c',1,'Partita']]],
  ['data_5fora_1',['data_ora',['../struct_record_salvataggio.html#a0b9d87ad1171110acc87eceb553b4f4b',1,'RecordSalvataggio::data_ora'],['../struct_log_accesso.html#a0b9d87ad1171110acc87eceb553b4f4b',1,'LogAccesso::data_ora']]],
  ['data_5fsalvataggio_2',['data_salvataggio',['../struct_partita.html#a5f8c839254288a8437575c3dacbf3e53',1,'Partita']]],
  ['dataora_3',['dataOra',['../struct_record_accesso.html#a1111cba55cdc2252b4255e024e076d3a',1,'RecordAccesso']]],
  ['dati_5fpartita_4',['dati_partita',['../struct_record_salvataggio.html#af9f7ed8831b9147adf4623e6b6b6957e',1,'RecordSalvataggio']]],
  ['defeat_5fimg_5',['defeat_img',['../struct_grafica.html#a3bdc8d505a2cf7e6a76ad181fe02447b',1,'Grafica']]],
  ['deltaplano_6',['deltaplano',['../struct_grafica.html#a3a006da3ecdaafe849e42e6b40b82e95',1,'Grafica']]],
  ['difficolta_5fia_7',['difficolta_ia',['../struct_giocatore.html#a49038e3d62333255deed5db00059b0e0',1,'Giocatore']]],
  ['direzione_8',['direzione',['../struct_partita.html#a6505c8e9ac66c5a6ac679bc41647f100',1,'Partita']]],
  ['durata_5fanimazione_9',['durata_animazione',['../struct_partita.html#af4ce5a9b5f1674dcabeeeabe3c862748',1,'Partita']]]
];
