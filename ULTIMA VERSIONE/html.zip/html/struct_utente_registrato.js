var struct_utente_registrato =
[
    [ "nickname", "struct_utente_registrato.html#aa4466b4e778da008191fbde9c2eecee3", null ],
    [ "password", "struct_utente_registrato.html#a31e8e8d75a558616beda2db0705befb4", null ],
    [ "ultima_azione", "struct_utente_registrato.html#ad0cea935d663716dccfe41a2bce92ec3", null ],
    [ "ultimo_accesso", "struct_utente_registrato.html#a052c445c8bdf4c20acb05f23af2c0938", null ]
];