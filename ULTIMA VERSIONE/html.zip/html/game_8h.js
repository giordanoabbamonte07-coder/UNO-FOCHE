var game_8h =
[
    [ "Carta", "struct_carta.html", "struct_carta" ],
    [ "Giocatore", "struct_giocatore.html", "struct_giocatore" ],
    [ "Partita", "struct_partita.html", "struct_partita" ],
    [ "RecordSalvataggio", "struct_record_salvataggio.html", "struct_record_salvataggio" ],
    [ "CARTA_ALTEZZA", "game_8h.html#a4cbcfaf3f2acf5c85d0d91eb928bf0cf", null ],
    [ "CARTA_LARGHEZZA", "game_8h.html#a5f25862f5aaf31948e307f08d7fc9376", null ],
    [ "COLORE_TESTO_DATA", "game_8h.html#aa54e9dcd9721049babd2c1cd469363de", null ],
    [ "COLORE_TESTO_EVENTO", "game_8h.html#ab9297a173856fc545a0657edb2aaa680", null ],
    [ "MANO_MAX", "game_8h.html#a9badf708e62e4e95261605dae49b7f08", null ],
    [ "MAZZO_TOTALE", "game_8h.html#a768cbc191f129e6802167a6cd8d6c7c7", null ],
    [ "SCHERMO_ALTEZZA", "game_8h.html#af98d217b28f157b70acf74bdc4c7e021", null ],
    [ "SCHERMO_LARGHEZZA", "game_8h.html#a5944cd052f21977cdd5318d16f067178", null ],
    [ "Colore", "game_8h.html#a030035d63f7ea5baefdfe9a53844d27c", [
      [ "ROSSO", "game_8h.html#a030035d63f7ea5baefdfe9a53844d27caf31d451540fbe9019951dc44d57cada9", null ],
      [ "GIALLO", "game_8h.html#a030035d63f7ea5baefdfe9a53844d27cab43fc5129914206a77c76e0cffd20df2", null ],
      [ "VERDE", "game_8h.html#a030035d63f7ea5baefdfe9a53844d27caf9efd9e6bd17c0580d8a0432ba1b04a2", null ],
      [ "BLU", "game_8h.html#a030035d63f7ea5baefdfe9a53844d27ca26d3f814fefb4d00336affb21a2f55b9", null ],
      [ "NERO", "game_8h.html#a030035d63f7ea5baefdfe9a53844d27ca40019d0f9c04951a840bde24c579e876", null ]
    ] ],
    [ "Tipo", "game_8h.html#adbc6fd1c40bcc87f0ffb9a41a4a4155a", [
      [ "NUMERO", "game_8h.html#adbc6fd1c40bcc87f0ffb9a41a4a4155aa078d5d968b860a21dd1fd7682986e984", null ],
      [ "SALTA", "game_8h.html#adbc6fd1c40bcc87f0ffb9a41a4a4155aa150773ba1df9e1914be905e7fcd09a4b", null ],
      [ "INVERTI", "game_8h.html#adbc6fd1c40bcc87f0ffb9a41a4a4155aabe537a246f0ae2786411ed65f0060fc5", null ],
      [ "PIU_DUE", "game_8h.html#adbc6fd1c40bcc87f0ffb9a41a4a4155aa581bd7682ee49c6ef2aed15703e34491", null ],
      [ "PIU_QUATTRO", "game_8h.html#adbc6fd1c40bcc87f0ffb9a41a4a4155aafca5f3472b00061a1859b891565b1bc4", null ],
      [ "CAMBIA_COLORE", "game_8h.html#adbc6fd1c40bcc87f0ffb9a41a4a4155aa093e6adbf5e8b70aafcc3b56c641f31c", null ]
    ] ],
    [ "AggiornaPartita", "game_8h.html#a265ba2456deefe1c0c901dff0ae92a09", null ],
    [ "GestisceInput", "game_8h.html#a425a6a4553385e952485f24b57faeff5", null ],
    [ "GiocatoreHaMosse", "game_8h.html#a9b7733214ce574619e98b158c49e005e", null ],
    [ "InizializzaPartita", "game_8h.html#a21fda4568f808bf067671e3b008bfd3d", null ],
    [ "OttieniPosizioneMazzoGiocatore", "game_8h.html#aa2bbfe121b559e821f99187c6733a282", null ],
    [ "Pesca", "game_8h.html#af3097c1c42b9872b194d5fc7b45c43e7", null ],
    [ "PuoGiocare", "game_8h.html#ab94485366daa9626d19bb5b74b5f1e29", null ],
    [ "nomi_colori_ita", "game_8h.html#a267ff02d706747f8c75e4b9a6de69411", null ]
];