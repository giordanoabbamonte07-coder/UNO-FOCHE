var game_8c =
[
    [ "AggiornaPartita", "game_8c.html#a265ba2456deefe1c0c901dff0ae92a09", null ],
    [ "GestisceInput", "game_8c.html#a425a6a4553385e952485f24b57faeff5", null ],
    [ "GiocatoreHaMosse", "game_8c.html#a9b7733214ce574619e98b158c49e005e", null ],
    [ "InizializzaPartita", "game_8c.html#a21fda4568f808bf067671e3b008bfd3d", null ],
    [ "OttieniPosizioneMazzoGiocatore", "game_8c.html#aa2bbfe121b559e821f99187c6733a282", null ],
    [ "Pesca", "game_8c.html#af3097c1c42b9872b194d5fc7b45c43e7", null ],
    [ "PuoGiocare", "game_8c.html#ab94485366daa9626d19bb5b74b5f1e29", null ],
    [ "SalvaPartita", "game_8c.html#acbae787be923d1daedbc25bb09910403", null ],
    [ "nomi_colori_ita", "game_8c.html#a267ff02d706747f8c75e4b9a6de69411", null ]
];