/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "My Project", "index.html", [
    [ "UNO Foca - Documentazione del codice", "md__r_e_a_d_m_e.html", [
      [ "Panoramica", "md__r_e_a_d_m_e.html#autotoc_md1", null ],
      [ "Tecnologie e dipendenze", "md__r_e_a_d_m_e.html#autotoc_md2", null ],
      [ "Compilazione ed esecuzione", "md__r_e_a_d_m_e.html#autotoc_md3", null ],
      [ "Struttura del progetto", "md__r_e_a_d_m_e.html#autotoc_md4", null ],
      [ "Flusso generale dell'applicazione", "md__r_e_a_d_m_e.html#autotoc_md5", null ],
      [ "Modulo <span class=\"tt\">game</span>", "md__r_e_a_d_m_e.html#autotoc_md6", [
        [ "Strutture principali", "md__r_e_a_d_m_e.html#autotoc_md7", null ],
        [ "Funzioni principali", "md__r_e_a_d_m_e.html#autotoc_md8", null ],
        [ "Regole implementate", "md__r_e_a_d_m_e.html#autotoc_md9", null ]
      ] ],
      [ "Modulo <span class=\"tt\">graphics</span>", "md__r_e_a_d_m_e.html#autotoc_md10", null ],
      [ "Modulo <span class=\"tt\">audio</span>", "md__r_e_a_d_m_e.html#autotoc_md11", null ],
      [ "Modulo <span class=\"tt\">menu</span>", "md__r_e_a_d_m_e.html#autotoc_md12", [
        [ "Dati utente", "md__r_e_a_d_m_e.html#autotoc_md13", null ],
        [ "Autenticazione", "md__r_e_a_d_m_e.html#autotoc_md14", null ]
      ] ],
      [ "Modulo <span class=\"tt\">menu_scelta</span>", "md__r_e_a_d_m_e.html#autotoc_md15", null ],
      [ "Modulo <span class=\"tt\">archivio</span>", "md__r_e_a_d_m_e.html#autotoc_md16", [
        [ "Salvataggi", "md__r_e_a_d_m_e.html#autotoc_md17", null ],
        [ "Statistiche", "md__r_e_a_d_m_e.html#autotoc_md18", null ]
      ] ],
      [ "File dati generati o usati", "md__r_e_a_d_m_e.html#autotoc_md19", null ],
      [ "Gestione degli asset", "md__r_e_a_d_m_e.html#autotoc_md20", null ],
      [ "Note di manutenzione", "md__r_e_a_d_m_e.html#autotoc_md21", null ],
      [ "Flusso tipico di gioco", "md__r_e_a_d_m_e.html#autotoc_md22", null ],
      [ "File principali da consultare", "md__r_e_a_d_m_e.html#autotoc_md23", null ]
    ] ],
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Structure Index", "classes.html", null ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", null ],
        [ "Variables", "functions_vars.html", null ]
      ] ]
    ] ],
    [ "Files", "files.html", [
      [ "File List", "files.html", "files_dup" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", null ],
        [ "Functions", "globals_func.html", null ],
        [ "Variables", "globals_vars.html", null ],
        [ "Enumerations", "globals_enum.html", null ],
        [ "Enumerator", "globals_eval.html", null ],
        [ "Macros", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.html",
"struct_menu_scelta.html#ab916f81ef206d996f5cc47719e0e2961"
];

const SYNCONMSG = 'click to disable panel synchronization';
const SYNCOFFMSG = 'click to enable panel synchronization';
const LISTOFALLMEMBERS = 'List of all members';