var menu__scelta_8h =
[
    [ "MenuScelta", "struct_menu_scelta.html", "struct_menu_scelta" ],
    [ "STATO_MENU_SCELTA_CORRENTE", "menu__scelta_8h.html#a0d9b8b381264683154f440260c58cca9", null ],
    [ "VAI_1VS1", "menu__scelta_8h.html#a496810aba8c641824ff194cc1a8d0019", null ],
    [ "VAI_ARCHIVIO", "menu__scelta_8h.html#a98cff792e2069ed18baa47f4c1fe595d", null ],
    [ "VAI_IMPOSTAZIONI", "menu__scelta_8h.html#a91b43b6674fca50a5664b29fcba5b05e", null ],
    [ "VAI_INDIETRO", "menu__scelta_8h.html#a570b56abe9045f6ef57a9bc3705caa84", null ],
    [ "VAI_MULTIGIOCATORE", "menu__scelta_8h.html#ab8c21e22ebac4b86a10a70f27139d1fa", null ],
    [ "VAI_REGOLE", "menu__scelta_8h.html#acdc7329b766c4a8af8cdff608bdf2dce", null ],
    [ "AggiornaDisegnaMenuScelta", "menu__scelta_8h.html#ad06c7e7d5f32ae699ac9ec5356124236", null ],
    [ "DeinizializzaMenuScelta", "menu__scelta_8h.html#a3a6e4fc29b651931c6b88fa43c8b04db", null ],
    [ "InizializzaMenuScelta", "menu__scelta_8h.html#ab3588acfa6e1da1846ff4dd90a605003", null ]
];