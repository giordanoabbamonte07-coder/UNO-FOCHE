var struct_carta =
[
    [ "colore", "struct_carta.html#a489426ff15ee3d43b4fa14d4760cb232", null ],
    [ "tipo", "struct_carta.html#a2c78f147398843ba78ded425dbb948c4", null ],
    [ "valore", "struct_carta.html#a303dfe0e1366c04c2e307a2536290f29", null ]
];