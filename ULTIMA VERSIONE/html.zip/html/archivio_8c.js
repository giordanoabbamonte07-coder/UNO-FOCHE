var archivio_8c =
[
    [ "CaricaPartiteSospeseUtente", "archivio_8c.html#a58e05485dbee98bd3004e25e3135335e", null ],
    [ "DisegnaArchivioStorico", "archivio_8c.html#a0a97c89f0e9c7d9e2bab78f222950aca", null ],
    [ "EliminaPartitaDaArchivio", "archivio_8c.html#a4bcf966145e0aee2e1064a7768b3d350", null ],
    [ "InizializzaRisorseArchivio", "archivio_8c.html#a55712d53701eaf266a8c7cd6dbc59cdd", null ],
    [ "OttieniStatisticheUtente", "archivio_8c.html#a5c1889226e8e84b71513037a0e889dab", null ],
    [ "PreparaArchivioStorico", "archivio_8c.html#aac875619d353e8f9f4c6087c7efa283d", null ],
    [ "SalvaPartitaSospesa", "archivio_8c.html#af8d26044be1ee4d4819311d8ea786576", null ],
    [ "SalvaRisultatoPartita", "archivio_8c.html#a25074f360d01d5d6451ed7206b9f282e", null ],
    [ "ScaricaRisorseArchivio", "archivio_8c.html#a1e0acc9358a505da02f123c0d12eb562", null ]
];