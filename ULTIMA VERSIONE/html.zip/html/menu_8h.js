var menu_8h =
[
    [ "MenuGrafica", "struct_menu_grafica.html", "struct_menu_grafica" ],
    [ "UtenteRegistrato", "struct_utente_registrato.html", "struct_utente_registrato" ],
    [ "StatoGioco", "menu_8h.html#a9e7662a03c3966203757e9c0186bd354", [
      [ "STATO_MENU", "menu_8h.html#a9e7662a03c3966203757e9c0186bd354afd452cc56d1447dfe216245859c0f8f8", null ],
      [ "STATO_ACCEDI", "menu_8h.html#a9e7662a03c3966203757e9c0186bd354aece4d3ebaf169eeb79486e97f740a164", null ],
      [ "STATO_REGISTRATI", "menu_8h.html#a9e7662a03c3966203757e9c0186bd354aefe875b4f1fe2f8f7064a783bb097fd1", null ],
      [ "STATO_DEBUG", "menu_8h.html#a9e7662a03c3966203757e9c0186bd354a7293663360468110a75221cd700ce0f7", null ],
      [ "STATO_MENU_SCELTA", "menu_8h.html#a9e7662a03c3966203757e9c0186bd354ad020e04077c0923289310174fb456c70", null ],
      [ "STATO_GIOCO", "menu_8h.html#a9e7662a03c3966203757e9c0186bd354aa1eda7dce686f88eaa8ce8344e31af4a", null ],
      [ "STATO_REGOLE", "menu_8h.html#a9e7662a03c3966203757e9c0186bd354abd208c7da89cb3d93a809eb8efd854d7", null ],
      [ "STATO_IMPOSTAZIONI", "menu_8h.html#a9e7662a03c3966203757e9c0186bd354a69f72c9f888b2a4c171c875a5ee9d525", null ],
      [ "STATO_ARCHIVIO", "menu_8h.html#a9e7662a03c3966203757e9c0186bd354a7abda57556cf863f1618afbb6ddb6e47", null ],
      [ "STATO_STATISTICHE", "menu_8h.html#a9e7662a03c3966203757e9c0186bd354a6cd1163aa7d278fdaecc1e919eaa9afc", null ]
    ] ],
    [ "AggiornaDisegnaMenu", "menu_8h.html#ac22263d5b85dfe545d8289b50f82cf3b", null ],
    [ "GestisciSchermataAuth", "menu_8h.html#aedaf59d96aedebada1c5aeed178097d9", null ],
    [ "InizializzaMenu", "menu_8h.html#a784d0026d039ae89a37b76bb9cb93c65", null ],
    [ "ScaricaMenu", "menu_8h.html#acdb1b7396af9f3b617830c37bc9d5bb6", null ]
];