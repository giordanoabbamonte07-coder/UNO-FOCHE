var annotated_dup =
[
    [ "Carta", "struct_carta.html", "struct_carta" ],
    [ "Giocatore", "struct_giocatore.html", "struct_giocatore" ],
    [ "Grafica", "struct_grafica.html", "struct_grafica" ],
    [ "LogAccesso", "struct_log_accesso.html", "struct_log_accesso" ],
    [ "MenuGrafica", "struct_menu_grafica.html", "struct_menu_grafica" ],
    [ "MenuScelta", "struct_menu_scelta.html", "struct_menu_scelta" ],
    [ "Partita", "struct_partita.html", "struct_partita" ],
    [ "RecordAccesso", "struct_record_accesso.html", "struct_record_accesso" ],
    [ "RecordSalvataggio", "struct_record_salvataggio.html", "struct_record_salvataggio" ],
    [ "UtenteRegistrato", "struct_utente_registrato.html", "struct_utente_registrato" ]
];