var struct_menu_grafica =
[
    [ "btn_accedi", "struct_menu_grafica.html#ace41d3a3497287bb566d8cf02b7caf43", null ],
    [ "btn_ospite", "struct_menu_grafica.html#a319c92415b33fc3fbf8bdebd46b0dc6c", null ],
    [ "btn_registrati", "struct_menu_grafica.html#a8f47806c53c861b1306a7524be286ac8", null ],
    [ "campo_attivo", "struct_menu_grafica.html#a7b271356cc5af1fadbde0ce4847077f2", null ],
    [ "frame_counter", "struct_menu_grafica.html#a314b72c8b8d68e6dbc30c4d374912519", null ],
    [ "nickname", "struct_menu_grafica.html#a64be4233774119fecc2ecf04f0b490e4", null ],
    [ "password", "struct_menu_grafica.html#a9ff5f387df67f4aa7fed563cd905bce8", null ],
    [ "sfondo", "struct_menu_grafica.html#a90a2b678ce087c70623f1efbe51b84e9", null ],
    [ "sfondo_accedi", "struct_menu_grafica.html#a1c775d69a90a31ae8cd25bbfdc077a21", null ],
    [ "sfondo_registrati", "struct_menu_grafica.html#a26b54c15eaada7509f5633b7990d7303", null ],
    [ "tex_password", "struct_menu_grafica.html#a28b65360e2d43d19ad8240ef85e007bd", null ],
    [ "tex_utente", "struct_menu_grafica.html#a6703520234c955336a846ca639e980e4", null ]
];