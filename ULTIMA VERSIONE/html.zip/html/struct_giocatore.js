var struct_giocatore =
[
    [ "difficolta_ia", "struct_giocatore.html#a49038e3d62333255deed5db00059b0e0", null ],
    [ "ha_notificato_ultima", "struct_giocatore.html#ae53b58247060acddcec8991a3f6e7f54", null ],
    [ "mano", "struct_giocatore.html#a8edfe5e592f246e047d9722698b536e9", null ],
    [ "num_carte", "struct_giocatore.html#aa333f9c5903d651051b9002f27d76826", null ]
];