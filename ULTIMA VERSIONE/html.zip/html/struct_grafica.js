var struct_grafica =
[
    [ "btn_sospendi", "struct_grafica.html#a43afa14845e66de51023427d72f498e5", null ],
    [ "carte", "struct_grafica.html#a7c627bd1fe9469884fad0c4869256288", null ],
    [ "defeat_img", "struct_grafica.html#a3bdc8d505a2cf7e6a76ad181fe02447b", null ],
    [ "deltaplano", "struct_grafica.html#a3a006da3ecdaafe849e42e6b40b82e95", null ],
    [ "foca", "struct_grafica.html#ae0f4487faa5699f6f1c881698b2219ed", null ],
    [ "retro", "struct_grafica.html#ab894ac900979555aff76b2a677791fe7", null ],
    [ "sfondo", "struct_grafica.html#a90a2b678ce087c70623f1efbe51b84e9", null ],
    [ "win_img", "struct_grafica.html#a678afc15010a3bf2c56c8ffcf5502b7c", null ]
];