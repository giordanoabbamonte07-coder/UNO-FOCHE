var struct_log_accesso =
[
    [ "data_ora", "struct_log_accesso.html#a0b9d87ad1171110acc87eceb553b4f4b", null ],
    [ "nickname", "struct_log_accesso.html#aa4466b4e778da008191fbde9c2eecee3", null ],
    [ "password", "struct_log_accesso.html#a31e8e8d75a558616beda2db0705befb4", null ],
    [ "tipo_azione", "struct_log_accesso.html#a2a329361c52810645698d6ec765fa999", null ]
];