var menu__scelta_8c =
[
    [ "SCHERMO_ALTEZZA", "menu__scelta_8c.html#af98d217b28f157b70acf74bdc4c7e021", null ],
    [ "SCHERMO_LARGHEZZA", "menu__scelta_8c.html#a5944cd052f21977cdd5318d16f067178", null ],
    [ "AggiornaDisegnaMenuScelta", "menu__scelta_8c.html#ad06c7e7d5f32ae699ac9ec5356124236", null ],
    [ "DeinizializzaMenuScelta", "menu__scelta_8c.html#a3a6e4fc29b651931c6b88fa43c8b04db", null ],
    [ "InizializzaMenuScelta", "menu__scelta_8c.html#ab3588acfa6e1da1846ff4dd90a605003", null ]
];