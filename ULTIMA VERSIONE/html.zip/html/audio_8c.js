var audio_8c =
[
    [ "CloseAudio", "audio_8c.html#abc629cd09bb702266545d28b5a436814", null ],
    [ "ImpostaStatoEffetti", "audio_8c.html#abfd4b86126de797ff51b88f8dcf87f87", null ],
    [ "ImpostaStatoMusica", "audio_8c.html#a34f61171aedc721009397790e6dbb0df", null ],
    [ "InitAudio", "audio_8c.html#a54d939106d7dd8bd3c4d00ca817e4d25", null ],
    [ "PlayBackgroundMusic", "audio_8c.html#aa0b52ffc919e93ab9420be04885f9aa6", null ],
    [ "PlayCardSound", "audio_8c.html#a0a8382ceeead4f700d51fe4048e740bc", null ],
    [ "PlayDefeatSound", "audio_8c.html#a5b056503149723e47e3c4a9fbb916c4e", null ],
    [ "PlayWinSound", "audio_8c.html#ab43514d467398d38042f3eaea35cf500", null ],
    [ "StopBackgroundMusic", "audio_8c.html#ac4ebc62c11c1cce00580c03e2c4dbcca", null ],
    [ "UpdateAudio", "audio_8c.html#aa55afe391362b8ee65cf6b504117ed2f", null ]
];