var main_8c =
[
    [ "RecordAccesso", "struct_record_accesso.html", "struct_record_accesso" ],
    [ "main", "main_8c.html#a840291bc02cba5474a4cb46a9b9566fe", null ],
    [ "ScriviLogAccessoBinario", "main_8c.html#afbc3ace6d281344b83da278db922e505", null ],
    [ "btnAvanti", "main_8c.html#ae16ceed85cbf05cc67bca1125b253d3a", null ],
    [ "btnIndietro", "main_8c.html#a4c42545da65859b4ed64c59a50e54317", null ],
    [ "rectAvanti", "main_8c.html#ae365c6067c2f5a54d0d1595f8fa1c6ec", null ],
    [ "rectIndietro", "main_8c.html#ad887d409244d4a4d47f14a4d90d263cd", null ],
    [ "sconfitteUtente", "main_8c.html#a19bd45f42e6bcc16d47956abde508bdb", null ],
    [ "sfondoStatistiche", "main_8c.html#ac9da2322d5949840a7837a36348757e6", null ],
    [ "vittorieUtente", "main_8c.html#a6143e852a422f7a521b43f81705e976f", null ]
];