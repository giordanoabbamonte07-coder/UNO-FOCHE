var files_dup =
[
    [ "archivio.c", "archivio_8c.html", "archivio_8c" ],
    [ "archivio.h", "archivio_8h.html", "archivio_8h" ],
    [ "audio.c", "audio_8c.html", "audio_8c" ],
    [ "audio.h", "audio_8h.html", "audio_8h" ],
    [ "game.c", "game_8c.html", "game_8c" ],
    [ "game.h", "game_8h.html", "game_8h" ],
    [ "graphics.c", "graphics_8c.html", "graphics_8c" ],
    [ "graphics.h", "graphics_8h.html", "graphics_8h" ],
    [ "main.c", "main_8c.html", "main_8c" ],
    [ "menu.c", "menu_8c.html", "menu_8c" ],
    [ "menu.h", "menu_8h.html", "menu_8h" ],
    [ "menu_scelta.c", "menu__scelta_8c.html", "menu__scelta_8c" ],
    [ "menu_scelta.h", "menu__scelta_8h.html", "menu__scelta_8h" ]
];