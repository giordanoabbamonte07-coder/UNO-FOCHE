var struct_record_salvataggio =
[
    [ "data_ora", "struct_record_salvataggio.html#a0b9d87ad1171110acc87eceb553b4f4b", null ],
    [ "dati_partita", "struct_record_salvataggio.html#af9f7ed8831b9147adf4623e6b6b6957e", null ],
    [ "nickname", "struct_record_salvataggio.html#a64be4233774119fecc2ecf04f0b490e4", null ]
];