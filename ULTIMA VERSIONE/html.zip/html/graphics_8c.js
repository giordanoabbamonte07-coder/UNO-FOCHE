var graphics_8c =
[
    [ "CaricaSicuro", "graphics_8c.html#aafdc5beb9128c3f400b3592a23adb3fb", null ],
    [ "CreaFallback", "graphics_8c.html#aab5f6f3bf7cacfe7aee1d9245df34127", null ],
    [ "DisegnaCarta", "graphics_8c.html#adffc6d1ec2312f9f68b3f15395e811f7", null ],
    [ "DisegnaPartita", "graphics_8c.html#af80ef27d7924e3e196fb780c38d31af1", null ],
    [ "DisegnaTestoPixelGrassetto", "graphics_8c.html#a7b41d6447819a799f28ec26a8ee65d9b", null ],
    [ "EvidenziaCarta", "graphics_8c.html#a8e5d8ee21a78ad39eadc32b7500effbf", null ],
    [ "InizializzaGrafica", "graphics_8c.html#a1a1f999ac837e2860330667c594bfc48", null ],
    [ "OttieniCarta", "graphics_8c.html#ad959c3c570127ad6990032e946026d57", null ],
    [ "ScaricaGrafica", "graphics_8c.html#acf092cde69a7326412b8967851c26b8e", null ],
    [ "nomi_colore_gfx", "graphics_8c.html#a700c15569035e4b93942d36139c4732b", null ]
];