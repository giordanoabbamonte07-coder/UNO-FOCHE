var struct_record_accesso =
[
    [ "azione", "struct_record_accesso.html#a1a51a5d930bd53beae10cfe8bd0baf58", null ],
    [ "dataOra", "struct_record_accesso.html#a1111cba55cdc2252b4255e024e076d3a", null ],
    [ "pass", "struct_record_accesso.html#ade137af880b61e4c68fb2dcc274dd1c0", null ],
    [ "user", "struct_record_accesso.html#ab34a32fb3324f0fc33c8d7d44c46ebf9", null ]
];