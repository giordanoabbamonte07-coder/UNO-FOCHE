var menu_8c =
[
    [ "LogAccesso", "struct_log_accesso.html", "struct_log_accesso" ],
    [ "AggiornaDisegnaMenu", "menu_8c.html#ac22263d5b85dfe545d8289b50f82cf3b", null ],
    [ "GestisciSchermataAuth", "menu_8c.html#aedaf59d96aedebada1c5aeed178097d9", null ],
    [ "InizializzaMenu", "menu_8c.html#a784d0026d039ae89a37b76bb9cb93c65", null ],
    [ "ScaricaMenu", "menu_8c.html#acdb1b7396af9f3b617830c37bc9d5bb6", null ]
];